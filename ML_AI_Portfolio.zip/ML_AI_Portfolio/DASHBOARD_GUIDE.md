# ML-AI Portfolio Dashboard Guide

## Quick Start

### Option 1: Click & Launch (Easiest)
1. Double-click **`START_DASHBOARD.bat`** in this folder
2. The dashboard window will open
3. Click any project's **[LAUNCH PROJECT]** button
4. Project runs in new window

### Option 2: Terminal
```bash
cd ML_AI_Portfolio
python dashboard.py
```

---

## Dashboard Features

### Main Interface
- **10 Project Cards** - Each with description, type, and accuracy
- **Color-coded Project Types** - Easy visual identification
- **Launch Buttons** - One-click project execution
- **Info Buttons** - View detailed project information
- **Scrollable List** - Browse all projects smoothly

### Project Information Available
- Project number and name
- Project type (NLP, Deep Learning, ML, etc.)
- Accuracy/performance metrics
- Full description
- File location
- Technical approach

---

## How to Use

### Launching a Project

1. **Scroll** through the dashboard to find your project
2. **Click [LAUNCH PROJECT]** on any project card
3. A new window will open and run the project
4. The project executes and generates outputs (PNG files, JSON data, etc.)

### Getting Project Details

1. **Click [INFO]** on any project card
2. A detailed information window opens
3. Review the project description and technical details
4. Close the window to return to dashboard

### Project Output Files

Each project generates output files in the `projects/` folder:
- `.png` files - Visualizations and analysis plots
- `.json` files - Data and results
- Console output - Performance metrics and logs

---

## Project List (10 Total)

| # | Project | Type | Performance |
|---|---------|------|-------------|
| 01 | SMS Spam Classification | NLP | 100% |
| 02 | Waste Classification CNN | Deep Learning | 95% |
| 03 | Sentiment Analysis RNN | Deep Learning | 85% |
| 04 | MNIST Digit Recognition | Deep Learning | 97% |
| 05 | Random Forest Classification | ML Ensemble | 86% |
| 06 | Linear Regression Housing | ML | 85% R² |
| 07 | Decision Trees | ML | 95% |
| 08 | Bank Data Encoding | Data Eng | 60% compression |
| 09 | RAG Chatbot System | NLP/AI | Semantic retrieval |
| 10 | Task Manager | CLI App | Full CRUD |

---

## System Requirements

### Minimum
- Python 3.8+
- 4 GB RAM
- Windows/Mac/Linux

### Dependencies
All required packages are in `requirements.txt`:
```bash
pip install -r requirements.txt
```

Key libraries:
- **TensorFlow** - Deep learning
- **Scikit-learn** - Machine learning
- **Pandas/NumPy** - Data processing
- **Matplotlib/Seaborn** - Visualization

---

## Troubleshooting

### Dashboard Won't Start
```bash
# Check Python installation
python --version

# Try running directly
cd ML_AI_Portfolio
python dashboard.py
```

### Project Launch Fails
1. Check Python is in PATH
2. Verify `projects/` folder exists
3. Ensure dependencies are installed: `pip install -r requirements.txt`
4. Check project file exists

### Missing Dependencies
```bash
# Install all dependencies
pip install -r requirements.txt

# Or specific packages
pip install tensorflow scikit-learn pandas numpy matplotlib seaborn
```

---

## Project Details

### 01 - SMS Spam Classification
- **Technology**: NLP, K-Fold validation
- **Output**: ROC curve graph, classification metrics
- **Accuracy**: 100% on sample data

### 02 - Waste Classification CNN
- **Technology**: Convolutional Neural Network
- **Output**: CNN analysis, predictions
- **Accuracy**: 95% validation

### 03 - Sentiment Analysis RNN
- **Technology**: 3 LSTM architectures
- **Output**: Model comparison, training history
- **Accuracy**: 85% average

### 04 - MNIST Digit Recognition
- **Technology**: Dense Neural Network
- **Output**: Training plots, sample predictions
- **Accuracy**: 97%

### 05 - Random Forest Classification
- **Technology**: Ensemble learning
- **Output**: Confusion matrices, feature importance
- **Accuracy**: 86%

### 06 - Linear Regression Housing
- **Technology**: Linear regression with scaling
- **Output**: Regression analysis, residual plots
- **Accuracy**: 85% R²

### 07 - Decision Trees Analysis
- **Technology**: Classification & regression trees
- **Output**: Tree visualizations, feature importance
- **Accuracy**: 95%

### 08 - Bank Data Encoding
- **Technology**: Label encoding vs One-Hot
- **Output**: Encoding comparison, compression metrics
- **Result**: 60% compression achieved

### 09 - RAG Chatbot System
- **Technology**: Embeddings, vector search
- **Output**: Retrieval analysis, conversation logs
- **Features**: Semantic search, LLM-ready

### 10 - Task Manager
- **Technology**: CLI with JSON persistence
- **Features**: Add, list, complete, delete tasks
- **Output**: tasks.json persistence

---

## Advanced Usage

### Running Projects Directly
```bash
cd projects/
python 01_sms_spam_classifier.py
python 04_mnist_digit_recognition.py
python 09_rag_chatbot_system.py
```

### Batch Running (All Projects)
```bash
# Coming soon: Batch execution feature
```

### Custom Configuration
Edit project files in `projects/` folder to modify:
- Hyperparameters
- Dataset sizes
- Model architectures
- Output paths

---

## Project Structure

```
ML_AI_Portfolio/
├── dashboard.py                 # Main GUI dashboard
├── START_DASHBOARD.bat         # Easy launcher
├── requirements.txt            # Dependencies
├── README.md                   # Main documentation
├── PROJECTS_STATUS.md          # Project status
│
├── projects/                   # All 10 projects
│   ├── 01_sms_spam_classifier.py
│   ├── 02_waste_classification_cnn.py
│   ├── 03_sentiment_analysis_rnn.py
│   ├── 04_mnist_digit_recognition.py
│   ├── 05_random_forest_classification.py
│   ├── 06_linear_regression_housing.py
│   ├── 07_decision_trees_analysis.py
│   ├── 08_bank_encoding_compression.py
│   ├── 09_rag_chatbot_system.py
│   └── 10_task_manager.py
│
├── utils/                      # Shared utilities
├── data/                       # Datasets
└── results/                    # Output files
```

---

## Tips & Tricks

### Faster Loading
- Install GPU support for TensorFlow (optional)
- Close other applications to free RAM
- First run takes longer (model compilation)

### Better Performance
- Increase batch size in projects (faster but uses more RAM)
- Reduce number of epochs for testing
- Use CPU-optimized versions of libraries

### Customize Output
- Edit project files to save results in different formats
- Modify visualization styles (colors, fonts, sizes)
- Add additional metrics or analysis

---

## Support & Help

### Common Issues
1. **GUI doesn't appear** → Check Tkinter installation
2. **Projects slow** → Install GPU drivers for TensorFlow
3. **Memory errors** → Close other applications or reduce batch size
4. **Import errors** → Run `pip install -r requirements.txt`

### Resources
- **TensorFlow Docs**: https://www.tensorflow.org/
- **Scikit-learn Docs**: https://scikit-learn.org/
- **Python ML Community**: Stack Overflow, GitHub

---

## File Descriptions

| File | Purpose |
|------|---------|
| `dashboard.py` | Interactive GUI application |
| `START_DASHBOARD.bat` | Windows launcher script |
| `requirements.txt` | Python dependencies |
| `README.md` | Main documentation |
| `PROJECTS_STATUS.md` | Status of all projects |

---

**Last Updated**: 2026-05-04  
**Status**: ✅ All systems operational  
**Projects**: 10/10 complete and tested
