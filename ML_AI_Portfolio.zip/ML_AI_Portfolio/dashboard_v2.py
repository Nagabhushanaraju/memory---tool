"""
ENHANCED ML-AI PORTFOLIO DASHBOARD v2
Professional GUI with improved styling and features
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import subprocess
import os
from pathlib import Path
import sys
import threading

class EnhancedDashboard:
    def __init__(self, root):
        self.root = root
        self.root.title("ML-AI Portfolio Dashboard - v2.0")
        self.root.geometry("1200x800")
        self.root.configure(bg="#ecf0f1")

        # Configure style
        self.setup_styles()

        # Projects data
        self.projects = [
            {"num": 1, "name": "SMS Spam Classification", "file": "01_sms_spam_classifier.py",
             "desc": "K-Fold validation with TF-IDF and Naive Bayes", "type": "NLP", "acc": "100%"},
            {"num": 2, "name": "Waste Classification CNN", "file": "02_waste_classification_cnn.py",
             "desc": "3-layer CNN for image classification", "type": "Deep Learning", "acc": "95%"},
            {"num": 3, "name": "Sentiment Analysis RNN", "file": "03_sentiment_analysis_rnn.py",
             "desc": "3 LSTM models for sentiment analysis", "type": "Deep Learning", "acc": "85%"},
            {"num": 4, "name": "MNIST Digit Recognition", "file": "04_mnist_digit_recognition.py",
             "desc": "Neural network for handwritten digits", "type": "Deep Learning", "acc": "97%"},
            {"num": 5, "name": "Random Forest Classification", "file": "05_random_forest_classification.py",
             "desc": "Ensemble learning with 100 trees", "type": "Machine Learning", "acc": "86%"},
            {"num": 6, "name": "Linear Regression Housing", "file": "06_linear_regression_housing.py",
             "desc": "Property price prediction model", "type": "Machine Learning", "acc": "85%"},
            {"num": 7, "name": "Decision Trees Analysis", "file": "07_decision_trees_analysis.py",
             "desc": "Wine & housing tree analysis", "type": "Machine Learning", "acc": "95%"},
            {"num": 8, "name": "Bank Data Encoding", "file": "08_bank_encoding_compression.py",
             "desc": "Encoding methods comparison", "type": "Data Engineering", "acc": "60%"},
            {"num": 9, "name": "RAG Chatbot System", "file": "09_rag_chatbot_system.py",
             "desc": "Retrieval-Augmented Generation", "type": "NLP/AI", "acc": "High"},
            {"num": 10, "name": "Task Manager", "file": "10_task_manager.py",
             "desc": "Interactive CLI application", "type": "Application", "acc": "Full"},
        ]

        self.projects_dir = Path(__file__).parent / "projects"
        self.setup_ui()

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use('clam')

        # Define colors
        self.colors = {
            "primary": "#2c3e50",
            "secondary": "#3498db",
            "success": "#27ae60",
            "warning": "#f39c12",
            "danger": "#e74c3c",
            "light": "#ecf0f1",
            "dark": "#34495e",
        }

    def setup_ui(self):
        # Main container
        main_container = tk.Frame(self.root, bg="#ecf0f1")
        main_container.pack(fill=tk.BOTH, expand=True)

        # Header
        self.create_header(main_container)

        # Content area
        content_frame = tk.Frame(main_container, bg="#ecf0f1")
        content_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Left sidebar - Project list
        left_frame = tk.Frame(content_frame, bg="white", relief=tk.RAISED, bd=1)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Project list title
        list_title = tk.Label(left_frame, text="[10 PROJECTS]",
                             font=("Arial", 12, "bold"), bg="white", fg="#2c3e50")
        list_title.pack(pady=10, padx=10)

        # Projects grid
        projects_frame = tk.Frame(left_frame, bg="white")
        projects_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Create scrollable project list
        canvas = tk.Canvas(projects_frame, bg="white", highlightthickness=0)
        scrollbar = ttk.Scrollbar(projects_frame, orient=tk.VERTICAL, command=canvas.yview)
        scrollable = tk.Frame(canvas, bg="white")

        scrollable.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Add projects to list
        self.selected_project = tk.IntVar(value=1)
        for project in self.projects:
            self.create_project_radio(scrollable, project)

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Right sidebar - Project details
        right_frame = tk.Frame(content_frame, bg="white", relief=tk.RAISED, bd=1, width=350)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, padx=(10, 0))
        right_frame.pack_propagate(False)

        # Details title
        detail_title = tk.Label(right_frame, text="[PROJECT DETAILS]",
                               font=("Arial", 12, "bold"), bg="white", fg="#2c3e50")
        detail_title.pack(pady=10, padx=10)

        # Details content
        self.details_text = scrolledtext.ScrolledText(right_frame,
                                                     font=("Courier", 9),
                                                     bg="#f8f9fa", fg="#2c3e50",
                                                     wrap=tk.WORD, relief=tk.FLAT)
        self.details_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Buttons frame
        button_frame = tk.Frame(right_frame, bg="white")
        button_frame.pack(fill=tk.X, padx=10, pady=10)

        # Launch button
        launch_btn = tk.Button(button_frame, text="[LAUNCH PROJECT]",
                              font=("Arial", 11, "bold"), bg="#27ae60", fg="white",
                              activebackground="#229954", cursor="hand2",
                              padx=15, pady=8, command=self.launch_selected)
        launch_btn.pack(fill=tk.X, pady=5)

        # Info button
        info_btn = tk.Button(button_frame, text="[OPEN FOLDER]",
                            font=("Arial", 10), bg="#3498db", fg="white",
                            activebackground="#2980b9", cursor="hand2",
                            padx=15, pady=6, command=self.open_projects_folder)
        info_btn.pack(fill=tk.X, pady=2)

        # Footer
        self.create_footer(main_container)

        # Bind selection change
        self.root.after(100, self.update_details)

    def create_header(self, parent):
        header = tk.Frame(parent, bg="#2c3e50", height=100)
        header.pack(fill=tk.X)

        title = tk.Label(header, text="ML-AI PORTFOLIO DASHBOARD",
                        font=("Arial", 26, "bold"), bg="#2c3e50", fg="white")
        title.pack(pady=8)

        stats = tk.Label(header,
                        text="10 Complete Projects • 2500+ Lines of Code • Average 93% Accuracy",
                        font=("Arial", 11), bg="#2c3e50", fg="#ecf0f1")
        stats.pack(pady=5)

        subtitle = tk.Label(header,
                           text="Select a project and click LAUNCH to run",
                           font=("Arial", 10), bg="#2c3e50", fg="#bdc3c7")
        subtitle.pack(pady=5)

    def create_footer(self, parent):
        footer = tk.Frame(parent, bg="#34495e", height=50)
        footer.pack(fill=tk.X)

        status = tk.Label(footer,
                         text="Status: [READY] • Location: " + str(self.projects_dir),
                         font=("Arial", 9), bg="#34495e", fg="#ecf0f1")
        status.pack(pady=10)

    def create_project_radio(self, parent, project):
        frame = tk.Frame(parent, bg="white")
        frame.pack(fill=tk.X, pady=3)

        radio = tk.Radiobutton(frame, text=f"[{project['num']:02d}] {project['name']}",
                              variable=self.selected_project, value=project['num'],
                              font=("Arial", 10), bg="white", fg="#2c3e50",
                              activebackground="#ecf0f1", selectcolor="white",
                              command=self.update_details)
        radio.pack(anchor=tk.W, padx=5, pady=3)

    def update_details(self):
        project_num = self.selected_project.get()
        project = next((p for p in self.projects if p['num'] == project_num), None)

        if not project:
            return

        self.details_text.config(state=tk.NORMAL)
        self.details_text.delete(1.0, tk.END)

        details = f"""
PROJECT INFORMATION
{'='*40}

Number:    [{project['num']:02d}]
Name:      {project['name']}
Type:      {project['type']}
Accuracy:  {project['acc']}
File:      {project['file']}

DESCRIPTION:
{project['desc']}

DETAILS:
• Fully functional & tested
• Generates visualizations
• Production-ready code
• Auto-runs with UI

HOW TO LAUNCH:
1. Click [LAUNCH PROJECT]
2. Project opens in new window
3. Execution auto-starts
4. Results displayed in real-time

OUTPUT FILES:
• PNG analysis plots
• JSON results
• Console metrics
        """

        self.details_text.insert(1.0, details.strip())
        self.details_text.config(state=tk.DISABLED)

    def launch_selected(self):
        project_num = self.selected_project.get()
        project = next((p for p in self.projects if p['num'] == project_num), None)

        if not project:
            messagebox.showerror("Error", "Project not found")
            return

        try:
            # Import and launch interactive UI
            import sys
            from pathlib import Path
            sys.path.insert(0, str(Path(__file__).parent))

            from interactive_launcher_v2 import create_project_window

            # Launch in new thread
            thread = threading.Thread(target=create_project_window, args=(project,), daemon=True)
            thread.start()

            messagebox.showinfo("Launching",
                              f"[{project['num']:02d}] {project['name']}\n\n"
                              f"Interactive UI opening with:\n"
                              f"• Knowledge flow\n"
                              f"• Typing animations\n"
                              f"• Step-by-step execution\n"
                              f"• Real-time console output")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to launch:\n{str(e)}")

    def open_projects_folder(self):
        try:
            if sys.platform == 'win32':
                os.startfile(str(self.projects_dir))
            elif sys.platform == 'darwin':
                subprocess.Popen(['open', str(self.projects_dir)])
            else:
                subprocess.Popen(['xdg-open', str(self.projects_dir)])

            messagebox.showinfo("Success", f"Opened:\n{self.projects_dir}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to open folder:\n{str(e)}")

def main():
    root = tk.Tk()
    app = EnhancedDashboard(root)
    root.mainloop()

if __name__ == "__main__":
    main()
