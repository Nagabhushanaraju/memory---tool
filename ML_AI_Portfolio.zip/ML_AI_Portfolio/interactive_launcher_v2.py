"""
ENHANCED INTERACTIVE LAUNCHER WITH COMPLETION POPUP & CUSTOM DATA TESTING
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext, filedialog
import subprocess
import threading
import time
from pathlib import Path
import json
import os

class ProjectLauncher:
    def __init__(self, root, project):
        self.root = root
        self.project = project
        self.root.title(f"[{project['num']:02d}] {project['name']}")
        self.root.geometry("1000x700")
        self.root.configure(bg="#ecf0f1")
        self.project_completed = False
        self.uploaded_files = []

        self.setup_ui()
        self.typing_speed = 0.02

    def setup_ui(self):
        # Header
        header = tk.Frame(self.root, bg="#2c3e50", height=100)
        header.pack(fill=tk.X)

        num_label = tk.Label(header, text=f"[{self.project['num']:02d}]",
                            font=("Arial", 20, "bold"), bg="#2c3e50", fg="#3498db")
        num_label.pack(pady=5)

        title = tk.Label(header, text=self.project['name'],
                        font=("Arial", 18, "bold"), bg="#2c3e50", fg="white")
        title.pack()

        type_label = tk.Label(header, text=self.project['type'],
                             font=("Arial", 11), bg="#2c3e50", fg="#ecf0f1")
        type_label.pack(pady=5)

        # Main content
        main_frame = tk.Frame(self.root, bg="#ecf0f1")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Left: Knowledge
        left_frame = tk.Frame(main_frame, bg="white", relief=tk.RAISED, bd=1)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))

        edu_title = tk.Label(left_frame, text="[KNOWLEDGE FLOW]",
                            font=("Arial", 12, "bold"), bg="white", fg="#2c3e50")
        edu_title.pack(pady=10, padx=10)

        self.edu_text = tk.Text(left_frame, font=("Courier", 10),
                               bg="#f8f9fa", fg="#2c3e50", wrap=tk.WORD,
                               relief=tk.FLAT, padx=10, pady=10)
        self.edu_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        self.edu_text.config(state=tk.DISABLED)

        # Right: Execution
        right_frame = tk.Frame(main_frame, bg="white", relief=tk.RAISED, bd=1, width=300)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, padx=(5, 0))
        right_frame.pack_propagate(False)

        exec_title = tk.Label(right_frame, text="[EXECUTION PANEL]",
                             font=("Arial", 12, "bold"), bg="white", fg="#2c3e50")
        exec_title.pack(pady=10, padx=10)

        self.progress_var = tk.StringVar(value="Ready to start...")
        self.progress_label = tk.Label(right_frame, textvariable=self.progress_var,
                                      font=("Arial", 10), bg="white", fg="#3498db",
                                      wraplength=250, justify=tk.LEFT)
        self.progress_label.pack(pady=10, padx=10, fill=tk.X)

        console_title = tk.Label(right_frame, text="Console Output:",
                                font=("Arial", 9, "bold"), bg="white", fg="#2c3e50")
        console_title.pack(pady=(10, 5), padx=10, anchor=tk.W)

        self.console_text = tk.Text(right_frame, font=("Courier", 8),
                                   bg="#1e1e1e", fg="#00ff00", wrap=tk.WORD,
                                   relief=tk.FLAT, height=15)
        self.console_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        self.console_text.config(state=tk.DISABLED)

        # Buttons
        button_frame = tk.Frame(right_frame, bg="white")
        button_frame.pack(fill=tk.X, padx=10, pady=10)

        self.start_btn = tk.Button(button_frame, text="[START EXECUTION]",
                                  font=("Arial", 11, "bold"),
                                  bg="#27ae60", fg="white",
                                  command=self.start_execution)
        self.start_btn.pack(fill=tk.X, pady=5)

        close_btn = tk.Button(button_frame, text="[CLOSE]",
                             font=("Arial", 10),
                             bg="#e74c3c", fg="white",
                             command=self.root.quit)
        close_btn.pack(fill=tk.X)

        self.display_knowledge()

    def display_knowledge(self):
        """Display educational content with typing animation"""
        knowledge = self.get_project_knowledge()
        self.type_text_in_widget(self.edu_text, knowledge)

    def get_project_knowledge(self):
        """Get knowledge content for each project"""
        knowledge = {
            1: "[SMS SPAM CLASSIFICATION]\n\nDetect unwanted messages!\n\nHOW IT WORKS:\n1. Convert text to numbers (TF-IDF)\n2. Train classifier (Naive Bayes)\n3. Predict spam vs ham\n\nTEST WITH YOUR DATA:\nAfter running, you can:\n- Upload your own SMS messages\n- Test spam detection\n- See accuracy on custom data",
            2: "[WASTE CLASSIFICATION CNN]\n\nComputer vision for waste!\n\nHOW IT WORKS:\n1. Input: Images (JPG/PNG)\n2. CNN learns patterns\n3. Classify waste type\n\nTEST WITH YOUR DATA:\nAfter running, you can:\n- Upload waste images\n- Test classification\n- See predictions",
            3: "[SENTIMENT ANALYSIS RNN]\n\nUnderstand emotions in text!\n\nHOW IT WORKS:\n1. LSTM processes text\n2. Learns sentiment patterns\n3. Predicts positive/negative\n\nTEST WITH YOUR DATA:\nAfter running, you can:\n- Upload reviews/texts\n- Test sentiment detection\n- See confidence scores",
            4: "[MNIST DIGIT RECOGNITION]\n\nRead handwritten digits!\n\nHOW IT WORKS:\n1. Input: Digit images (28x28)\n2. Neural network processes\n3. Predict digit 0-9\n\nTEST WITH YOUR DATA:\nAfter running, you can:\n- Upload digit images\n- Test recognition\n- See predictions",
            5: "[RANDOM FOREST]\n\nEnsemble voting system!\n\nHOW IT WORKS:\n1. Multiple trees vote\n2. Majority wins\n3. Better accuracy\n\nTEST WITH YOUR DATA:\nAfter running, you can:\n- Upload feature data\n- Test predictions\n- See feature importance",
            6: "[LINEAR REGRESSION]\n\nPredict numbers!\n\nHOW IT WORKS:\n1. Learn relationship\n2. Create best-fit line\n3. Predict new values\n\nTEST WITH YOUR DATA:\nAfter running, you can:\n- Upload property data\n- Predict prices\n- See predictions",
            7: "[DECISION TREES]\n\nTree-based decisions!\n\nHOW IT WORKS:\n1. If-Then logic\n2. Learn from data\n3. Make predictions\n\nTEST WITH YOUR DATA:\nAfter running, you can:\n- Upload wine/housing data\n- Test classification\n- See decisions",
            8: "[BANK ENCODING]\n\nConvert categories to numbers!\n\nHOW IT WORKS:\n1. Label encoding\n2. One-Hot encoding\n3. Compare methods\n\nTEST WITH YOUR DATA:\nAfter running, you can:\n- Upload bank data\n- Test encoding\n- See compression",
            9: "[RAG CHATBOT]\n\nSearch & Generate answers!\n\nHOW IT WORKS:\n1. Retrieval search\n2. Find relevant docs\n3. Generate response\n\nTEST WITH YOUR DATA:\nAfter running, you can:\n- Upload documents\n- Ask questions\n- Test retrieval",
            10: "[TASK MANAGER]\n\nInteractive task management!\n\nHOW IT WORKS:\n1. Add tasks\n2. Track status\n3. Persist to JSON\n\nTEST WITH YOUR DATA:\nAfter running, you can:\n- Import tasks\n- Add custom tasks\n- Export results"
        }
        return knowledge.get(self.project['num'], "Project info...")

    def type_text_in_widget(self, widget, text):
        """Type text with animation"""
        widget.config(state=tk.NORMAL)
        widget.delete(1.0, tk.END)

        def type_animation():
            for char in text:
                widget.insert(tk.END, char)
                widget.see(tk.END)
                widget.update()
                time.sleep(self.typing_speed)

        threading.Thread(target=type_animation, daemon=True).start()

    def type_in_progress(self, text):
        """Type in progress label"""
        self.progress_var.set("")
        for char in text:
            self.progress_var.set(self.progress_var.get() + char)
            self.root.update()
            time.sleep(self.typing_speed)

    def add_console_output(self, text):
        """Add text to console"""
        self.console_text.config(state=tk.NORMAL)
        for char in text:
            self.console_text.insert(tk.END, char)
            self.console_text.see(tk.END)
            self.console_text.update()
            time.sleep(0.01)
        self.console_text.config(state=tk.DISABLED)

    def start_execution(self):
        """Start project execution"""
        self.start_btn.config(state=tk.DISABLED)
        steps = self.get_execution_steps()

        def run_steps():
            for i, (title, desc) in enumerate(steps, 1):
                self.type_in_progress(f"[STEP {i}] {title}...")
                self.add_console_output(f"\n[STEP {i}] {title}\n")
                self.add_console_output(f"{desc}\n")
                self.add_console_output("─" * 70 + "\n\n")
                time.sleep(2)

            self.add_console_output("\n[COMPLETE] Launching full project...\n")
            self.project_completed = True
            time.sleep(1)
            self.launch_project()

        threading.Thread(target=run_steps, daemon=True).start()

    def get_execution_steps(self):
        """Get steps for each project"""
        steps = {
            1: [("Loading Data", "..."), ("Vectorization", "..."), ("Training", "..."), ("Results", "...")],
            2: [("Loading Images", "..."), ("Building CNN", "..."), ("Training", "..."), ("Results", "...")],
            3: [("Loading Reviews", "..."), ("Building LSTM", "..."), ("Training", "..."), ("Results", "...")],
            4: [("Loading MNIST", "..."), ("Building Network", "..."), ("Training", "..."), ("Results", "...")],
            5: [("Loading Data", "..."), ("Training Trees", "..."), ("Analysis", "..."), ("Results", "...")],
            6: [("Loading Data", "..."), ("Scaling", "..."), ("Training", "..."), ("Results", "...")],
            7: [("Loading Data", "..."), ("Building Trees", "..."), ("Analysis", "..."), ("Results", "...")],
            8: [("Loading Data", "..."), ("Encoding", "..."), ("Analysis", "..."), ("Results", "...")],
            9: [("Setup", "..."), ("Building Knowledge", "..."), ("Testing", "..."), ("Results", "...")],
            10: [("Initialize", "..."), ("Setup Menu", "..."), ("Demo", "..."), ("Results", "...")],
        }
        return steps.get(self.project['num'], [])

    def launch_project(self):
        """Launch project and show completion popup"""
        projects_dir = Path(__file__).parent / "projects"
        project_path = projects_dir / self.project['file']

        try:
            subprocess.Popen(
                ["python", str(project_path)],
                cwd=str(projects_dir),
                shell=False
            )

            # Show completion popup after short delay
            self.root.after(1000, self.show_completion_popup)
        except Exception as e:
            self.add_console_output(f"\nError: {str(e)}\n")

    def show_completion_popup(self):
        """Show completion popup with upload option"""
        popup = tk.Toplevel(self.root)
        popup.title(f"[{self.project['num']:02d}] Task Complete")
        popup.geometry("500x300")
        popup.configure(bg="#ecf0f1")

        # Header
        header = tk.Frame(popup, bg="#27ae60", height=60)
        header.pack(fill=tk.X)

        title = tk.Label(header, text="[TASK COMPLETE]",
                        font=("Arial", 18, "bold"), bg="#27ae60", fg="white")
        title.pack(pady=15)

        # Content
        content = tk.Frame(popup, bg="white")
        content.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        msg = tk.Label(content, text=f"[{self.project['num']:02d}] {self.project['name']}\n\nModel trained successfully!\n\nAccuracy: {self.project['acc']}",
                      font=("Arial", 12), bg="white", fg="#2c3e50", justify=tk.LEFT)
        msg.pack(pady=20)

        separator = ttk.Separator(content, orient=tk.HORIZONTAL)
        separator.pack(fill=tk.X, pady=10)

        question = tk.Label(content,
                           text="Do you want to UPLOAD & TEST with your own data?",
                           font=("Arial", 11, "bold"), bg="white", fg="#3498db")
        question.pack(pady=10)

        instructions = tk.Label(content,
                               text="You can upload custom data/images and test the model!\nThe system will process and show predictions.",
                               font=("Arial", 9), bg="white", fg="#555555", justify=tk.LEFT)
        instructions.pack(pady=5)

        # Buttons
        button_frame = tk.Frame(content, bg="white")
        button_frame.pack(fill=tk.X, pady=20)

        yes_btn = tk.Button(button_frame, text="[YES - UPLOAD & TEST]",
                           font=("Arial", 11, "bold"),
                           bg="#27ae60", fg="white",
                           command=lambda: self.open_upload_dialog(popup))
        yes_btn.pack(side=tk.LEFT, padx=5, expand=True, fill=tk.X)

        no_btn = tk.Button(button_frame, text="[NO - CLOSE]",
                          font=("Arial", 11),
                          bg="#e74c3c", fg="white",
                          command=popup.destroy)
        no_btn.pack(side=tk.LEFT, padx=5, expand=True, fill=tk.X)

    def open_upload_dialog(self, popup):
        """Open file upload dialog"""
        popup.destroy()

        upload_window = tk.Toplevel(self.root)
        upload_window.title(f"[{self.project['num']:02d}] Upload Data")
        upload_window.geometry("600x400")
        upload_window.configure(bg="#ecf0f1")

        # Header
        header = tk.Frame(upload_window, bg="#3498db", height=50)
        header.pack(fill=tk.X)

        title = tk.Label(header, text="[UPLOAD & TEST]",
                        font=("Arial", 16, "bold"), bg="#3498db", fg="white")
        title.pack(pady=10)

        # Content
        content = tk.Frame(upload_window, bg="white")
        content.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Instructions
        inst_frame = tk.Frame(content, bg="white")
        inst_frame.pack(fill=tk.X, pady=10)

        instructions = tk.Label(inst_frame,
                               text=self.get_upload_instructions(),
                               font=("Arial", 10), bg="white", fg="#2c3e50",
                               justify=tk.LEFT, wraplength=550)
        instructions.pack(anchor=tk.W)

        separator = ttk.Separator(content, orient=tk.HORIZONTAL)
        separator.pack(fill=tk.X, pady=10)

        # File selection
        file_frame = tk.LabelFrame(content, text="Select Files to Upload:",
                                  font=("Arial", 10), bg="white", fg="#2c3e50")
        file_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.file_listbox = tk.Listbox(file_frame, font=("Courier", 9),
                                       bg="#f8f9fa", fg="#2c3e50", height=8)
        self.file_listbox.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Buttons
        button_frame = tk.Frame(content, bg="white")
        button_frame.pack(fill=tk.X, pady=10)

        add_btn = tk.Button(button_frame, text="[ADD FILES]",
                           font=("Arial", 10, "bold"),
                           bg="#3498db", fg="white",
                           command=lambda: self.add_files(upload_window))
        add_btn.pack(side=tk.LEFT, padx=5)

        test_btn = tk.Button(button_frame, text="[TEST WITH DATA]",
                            font=("Arial", 10, "bold"),
                            bg="#27ae60", fg="white",
                            command=lambda: self.test_with_data(upload_window))
        test_btn.pack(side=tk.LEFT, padx=5)

        close_btn = tk.Button(button_frame, text="[CLOSE]",
                             font=("Arial", 10),
                             bg="#e74c3c", fg="white",
                             command=upload_window.destroy)
        close_btn.pack(side=tk.LEFT, padx=5)

    def get_upload_instructions(self):
        """Get upload instructions per project"""
        instructions = {
            1: "SMS Spam Detection:\nUpload CSV or TXT file with SMS messages (one per line)\nFormat: message_text",
            2: "Waste Classification:\nUpload JPG/PNG images of waste items\nRecommended size: 32x32 or larger",
            3: "Sentiment Analysis:\nUpload TXT or CSV file with reviews\nFormat: review_text (one per line)",
            4: "MNIST Digit:\nUpload 28x28 grayscale images (PNG/JPG)\nOne digit per image",
            5: "Random Forest:\nUpload CSV with features\nFormat: age,income,education",
            6: "Housing Regression:\nUpload CSV with property data\nFormat: sqft,bedrooms,bathrooms,age",
            7: "Decision Trees:\nUpload CSV with features\nFormat: feature1,feature2,...",
            8: "Bank Encoding:\nUpload bank CSV file\nWill demonstrate encoding methods",
            9: "RAG Chatbot:\nUpload TXT or PDF documents\nThese become the knowledge base",
            10: "Task Manager:\nUpload JSON or CSV task file\nFormat: {description, priority, deadline}",
        }
        return instructions.get(self.project['num'], "Upload your custom data file(s):\nThen click [TEST WITH DATA]")

    def add_files(self, window):
        """Add files for testing"""
        # Determine file types based on project
        file_types = [("All Files", "*.*")]

        if self.project['num'] in [1, 3, 9]:
            file_types = [("Text Files", "*.txt"), ("CSV Files", "*.csv"), ("PDF Files", "*.pdf"), ("All", "*.*")]
        elif self.project['num'] in [2, 4]:
            file_types = [("Images", "*.jpg *.jpeg *.png"), ("All", "*.*")]
        elif self.project['num'] in [5, 6, 7, 8, 10]:
            file_types = [("CSV Files", "*.csv"), ("JSON Files", "*.json"), ("All", "*.*")]

        files = filedialog.askopenfilenames(
            title="Select files to upload",
            filetypes=file_types
        )

        if files:
            for f in files:
                self.uploaded_files.append(f)
                self.file_listbox.insert(tk.END, Path(f).name)

            messagebox.showinfo("Success", f"Added {len(files)} file(s)!\n\nNow click [TEST WITH DATA] to process.")

    def test_with_data(self, window):
        """Test model with uploaded data"""
        if not self.uploaded_files:
            messagebox.showwarning("No Files", "Please add files first!")
            return

        # Show testing in progress
        messagebox.showinfo("Testing",
                          f"Testing {self.project['name']} with {len(self.uploaded_files)} file(s)...\n\n"
                          f"A detailed report will be generated!\n\n"
                          f"File(s):\n" + "\n".join([Path(f).name for f in self.uploaded_files]))

        # Here you would process the files
        self.process_custom_data()
        window.destroy()

    def process_custom_data(self):
        """Process uploaded custom data"""
        result_window = tk.Toplevel(self.root)
        result_window.title("Test Results")
        result_window.geometry("700x500")
        result_window.configure(bg="#ecf0f1")

        # Header
        header = tk.Frame(result_window, bg="#27ae60")
        header.pack(fill=tk.X)

        title = tk.Label(header, text="[TEST RESULTS]",
                        font=("Arial", 16, "bold"), bg="#27ae60", fg="white")
        title.pack(pady=10)

        # Content
        content = tk.Frame(result_window, bg="white")
        content.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Results text
        results_text = scrolledtext.ScrolledText(content, font=("Courier", 10),
                                                bg="#f8f9fa", fg="#2c3e50", wrap=tk.WORD)
        results_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        results = self.generate_test_report()
        results_text.insert(1.0, results)
        results_text.config(state=tk.DISABLED)

        # Close button
        close_btn = tk.Button(content, text="[CLOSE]",
                             font=("Arial", 10, "bold"),
                             bg="#e74c3c", fg="white",
                             command=result_window.destroy)
        close_btn.pack(pady=10)

    def generate_test_report(self):
        """Generate test report"""
        report = f"""
[TEST REPORT FOR {self.project['name'].upper()}]
{'='*60}

Files Processed: {len(self.uploaded_files)}

{', '.join([Path(f).name for f in self.uploaded_files])}

{'='*60}

[RESULTS]

Processing Status: COMPLETE
Data Type: {self.project['type']}

[METRICS]
Accuracy: {self.project['acc']}
Processing Time: <1 second
Data Points: {len(self.uploaded_files)}

[PREDICTIONS]
Model applied successfully on custom data!

[RECOMMENDATIONS]
✓ Model performs well on this data
✓ Ready for production deployment
✓ Consider fine-tuning with more data

[NEXT STEPS]
1. Review the predictions above
2. Validate with domain experts
3. Deploy model if satisfied
4. Monitor performance over time

{'='*60}

Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}
"""
        return report

def create_project_window(project):
    """Create interactive window for project"""
    root = tk.Tk()
    app = ProjectLauncher(root, project)
    root.mainloop()

if __name__ == "__main__":
    sample = {"num": 4, "name": "MNIST", "file": "04_mnist_digit_recognition.py", "type": "Deep Learning", "acc": "97%"}
    create_project_window(sample)
