#!/usr/bin/env python3
"""
╔════════════════════════════════════════════════════════════════════════════╗
║          🚀 ML-AI PORTFOLIO DASHBOARD - Comprehensive Toolkit 🚀          ║
║                    By Nagabhushana Raju S (Data Scientist)                ║
╚════════════════════════════════════════════════════════════════════════════╝

A professional showcase of 11+ machine learning & AI projects demonstrating
expertise in supervised learning, deep learning, NLP, RAG systems, and deployment.
"""

import os
import sys
from typing import Callable, Dict

# Color codes for terminal output
class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

def print_header():
    """Display the main dashboard header"""
    header = f"""
{Colors.BOLD}{Colors.HEADER}
╔═══════════════════════════════════════════════════════════════════════════╗
║                                                                           ║
║              🧠 ML-AI PORTFOLIO: COMPREHENSIVE DATA SCIENCE 🤖           ║
║                                                                           ║
║                  11+ Projects | 3000+ Lines of Code                      ║
║                    Accuracy: 93%+ | Production-Ready                     ║
║                                                                           ║
║            Developed by: Nagabhushana Raju S (Data Scientist)            ║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝
{Colors.ENDC}
    """
    print(header)

def print_projects_menu():
    """Display available projects"""
    menu = f"""
{Colors.OKBLUE}{Colors.BOLD}📚 SELECT A PROJECT:{Colors.ENDC}

  {Colors.OKCYAN}[1] SMS Spam Classification{Colors.ENDC}
      • Algorithm: Naive Bayes + TF-IDF
      • Performance: 97% accuracy
      • Techniques: K-Fold CV, ROC-AUC curves

  {Colors.OKCYAN}[2] Waste Classification (CNN){Colors.ENDC}
      • Architecture: Conv2D + MaxPooling + BatchNorm
      • Dataset: TrashNet (6 waste classes)
      • Performance: 95% validation accuracy

  {Colors.OKCYAN}[3] IMDB Sentiment Analysis (RNN){Colors.ENDC}
      • Models: LSTM with Embedding layer
      • Variants: 3 progressive versions
      • Performance: 85% test accuracy

  {Colors.OKCYAN}[4] MNIST Digit Recognition{Colors.ENDC}
      • Network: Dense Neural Network
      • Dataset: 60k training images
      • Performance: 97% test accuracy

  {Colors.OKCYAN}[5] Random Forest Classification{Colors.ENDC}
      • Dataset: Adult Census Income (30k+ records)
      • Model: Random Forest + Baseline Comparison
      • Performance: 86% accuracy on income prediction

  {Colors.OKCYAN}[6] Linear Regression - Housing{Colors.ENDC}
      • Dataset: Housing prices (13 features)
      • Metrics: MSE, RMSE, R² Score
      • Includes: Residual analysis & visualization

  {Colors.OKCYAN}[7] Decision Trees Analysis{Colors.ENDC}
      • Datasets: Wine classification, Housing regression
      • Techniques: Tree structure, Feature importance
      • Performance: 95% on wine classification

  {Colors.OKCYAN}[8] Bank Dataset Encoding{Colors.ENDC}
      • Focus: Data compression & categorical encoding
      • Methods: Label encoding, one-hot, ordinal
      • Performance: 88% with decision trees

  {Colors.OKCYAN}[9] RAG Chatbot System{Colors.ENDC}
      • Architecture: PDF + Embeddings + Vector Search
      • Tools: ChromaDB, Sentence Transformers
      • Use Case: Intelligent Q&A on documents

  {Colors.OKCYAN}[10] Personal Task Manager (Groq AI){Colors.ENDC}
       • AI Integration: Groq LLM agent
       • Features: Add, list, complete, delete tasks
       • Backend: CLI with persistent storage

  {Colors.OKCYAN}[11] Brain Tumor Detection (ADVANCED)⭐{Colors.ENDC}
       • Architecture: Ensemble (ResNet50 + EfficientNetV2 + ViT)
       • Performance: 99.03% validation, 97.70% test
       • Deployment: Flask web app + Docker

  {Colors.WARNING}[12] View Project Overview (This README){Colors.ENDC}

  {Colors.FAIL}[0] Exit Dashboard{Colors.ENDC}
    """
    print(menu)

def print_footer():
    """Display footer with stats"""
    footer = f"""
{Colors.BOLD}{Colors.HEADER}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
{Colors.ENDC}
{Colors.OKGREEN}📊 PORTFOLIO STATISTICS:{Colors.ENDC}
   • Total Projects: 11+ (10 mini-projects + 1 advanced)
   • Total Code: 3000+ lines
   • Average Accuracy: 93%+
   • Technologies: TensorFlow, PyTorch, Scikit-learn, LangChain, etc.
   • Deployment: Docker, Flask, Streamlit

{Colors.OKGREEN}🎯 KEY SKILLS DEMONSTRATED:{Colors.ENDC}
   ✅ Supervised Learning (Classification, Regression)
   ✅ Deep Learning (CNN, RNN, Transformers)
   ✅ Ensemble Methods & Stacking
   ✅ NLP & RAG Systems
   ✅ Medical AI (99%+ accuracy)
   ✅ Data Preprocessing & Feature Engineering
   ✅ Model Evaluation & Visualization
   ✅ Production Deployment

{Colors.OKGREEN}👨‍💻 DEVELOPER:{Colors.ENDC}
   Nagabhushana Raju S - Data Scientist & ML Engineer
   Specialization: Deep Learning, Medical AI, NLP

{Colors.BOLD}{Colors.HEADER}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
{Colors.ENDC}
    """
    print(footer)

def project_not_implemented(project_name: str):
    """Placeholder for projects (can be expanded with actual implementations)"""
    print(f"\n{Colors.WARNING}⚠️  {project_name} is available.{Colors.ENDC}")
    print(f"{Colors.WARNING}   Code is in: projects/{project_name.lower().replace(' ', '_')}.py{Colors.ENDC}")
    print(f"{Colors.OKGREEN}   To run: python projects/{project_name.lower().replace(' ', '_')}.py{Colors.ENDC}\n")

def show_project_info(project_num: int):
    """Show detailed info about a project"""
    projects_info = {
        1: ("SMS Spam Classification", "01_sms_spam_classifier"),
        2: ("Waste Classification", "02_waste_classification_cnn"),
        3: ("IMDB Sentiment Analysis", "03_sentiment_analysis_rnn"),
        4: ("MNIST Digit Recognition", "04_mnist_digit_recognition"),
        5: ("Random Forest Classification", "05_random_forest_classification"),
        6: ("Linear Regression - Housing", "06_linear_regression_housing"),
        7: ("Decision Trees Analysis", "07_decision_trees_analysis"),
        8: ("Bank Dataset Encoding", "08_bank_encoding_compression"),
        9: ("RAG Chatbot System", "09_rag_chatbot_system"),
        10: ("Task Manager (Groq AI)", "10_task_manager_groq"),
        11: ("Brain Tumor Detection", "../brain_tumor_detection")
    }

    if project_num in projects_info:
        name, path = projects_info[project_num]
        project_not_implemented(name)
        print(f"{Colors.OKCYAN}📂 Location: {path}{Colors.ENDC}")
        print(f"{Colors.OKCYAN}📖 For full details, see: README.md{Colors.ENDC}\n")
    else:
        print(f"{Colors.FAIL}❌ Invalid project number{Colors.ENDC}\n")

def show_readme():
    """Show project README"""
    readme_path = os.path.join(os.path.dirname(__file__), "README.md")
    if os.path.exists(readme_path):
        with open(readme_path, 'r') as f:
            content = f.read()
            print(f"\n{Colors.OKCYAN}{content}{Colors.ENDC}\n")
    else:
        print(f"{Colors.FAIL}❌ README.md not found{Colors.ENDC}\n")

def main():
    """Main dashboard loop"""
    print_header()

    while True:
        print_projects_menu()

        try:
            choice = input(f"\n{Colors.BOLD}Enter your choice (0-12): {Colors.ENDC}").strip()

            if choice == "0":
                print(f"\n{Colors.OKGREEN}✅ Thanks for exploring the ML-AI Portfolio!{Colors.ENDC}")
                print(f"{Colors.OKGREEN}👋 Goodbye! Happy learning & coding!{Colors.ENDC}\n")
                break
            elif choice in ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11"]:
                show_project_info(int(choice))
                input(f"{Colors.WARNING}Press Enter to continue...{Colors.ENDC}")
            elif choice == "12":
                show_readme()
                input(f"{Colors.WARNING}Press Enter to continue...{Colors.ENDC}")
            else:
                print(f"\n{Colors.FAIL}❌ Invalid choice. Please enter 0-12{Colors.ENDC}\n")
                input(f"{Colors.WARNING}Press Enter to continue...{Colors.ENDC}")
        except KeyboardInterrupt:
            print(f"\n\n{Colors.OKGREEN}✅ Dashboard closed by user.{Colors.ENDC}\n")
            break
        except Exception as e:
            print(f"\n{Colors.FAIL}❌ Error: {str(e)}{Colors.ENDC}\n")
            input(f"{Colors.WARNING}Press Enter to continue...{Colors.ENDC}")

if __name__ == "__main__":
    try:
        main()
        print_footer()
    except Exception as e:
        print(f"\n{Colors.FAIL}Fatal Error: {str(e)}{Colors.ENDC}\n")
        sys.exit(1)
