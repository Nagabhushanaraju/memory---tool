# 🚀 ML-AI Portfolio: Comprehensive Data Science Toolkit

A **professional-grade collection** of 10+ machine learning and AI projects showcasing expertise in supervised learning, deep learning, NLP, RAG systems, and more.

---

## 📂 Projects Included

### 1. **SMS Spam Classification** ✉️
- **Algorithm**: Naive Bayes + TF-IDF Vectorization
- **Validation**: 5-Fold Cross-Validation
- **Metrics**: ROC-AUC, Accuracy, Precision-Recall
- **Performance**: ~97% accuracy across folds
- **Location**: `projects/01_sms_spam_classifier.py`

### 2. **Waste Classification** 🗑️
- **Architecture**: CNN (Conv2D + MaxPooling + BatchNorm)
- **Dataset**: TrashNet (6 waste classes)
- **Preprocessing**: Rescaling normalization, 80-20 train-val split
- **Performance**: ~95% validation accuracy
- **Location**: `projects/02_waste_classification_cnn.py`

### 3. **IMDB Sentiment Analysis** 🎬
- **Architectures**: RNN/LSTM (3 progressive versions)
- **V1**: Basic LSTM with Embedding
- **V2**: Stacked LSTM + Early Stopping
- **V3**: Multi-layer LSTM + Advanced preprocessing
- **Performance**: ~85% test accuracy
- **Location**: `projects/03_sentiment_analysis_rnn.py`

### 4. **MNIST Digit Recognition** 🔢
- **Network**: Dense Neural Network (input→128→64→10)
- **Dataset**: 60,000 training images, 10,000 test
- **Activation**: ReLU (hidden), Softmax (output)
- **Performance**: ~97% test accuracy
- **Location**: `projects/04_mnist_digit_recognition.py`

### 5. **Random Forest Classification** 💰
- **Dataset**: Adult Census Income (30k+ records)
- **Model**: Random Forest + Decision Tree comparison
- **Features**: 14 demographic variables
- **Preprocessing**: Label encoding, missing value handling
- **Performance**: ~86% accuracy on income prediction
- **Location**: `projects/05_random_forest_classification.py`

### 6. **Linear Regression - Housing** 🏠
- **Dataset**: Housing prices with 13 features
- **Preprocessing**: Standardization, feature scaling
- **Metrics**: MSE, RMSE, R² Score
- **Visualization**: Residual plots, prediction curves
- **Location**: `projects/06_linear_regression_housing.py`

### 7. **Decision Trees Analysis** 🌳
- **Datasets**: Wine classification, Housing regression
- **Methods**: Pure decision trees, pruning strategies
- **Visualization**: Tree structure plots, feature importance
- **Performance**: ~95% on wine, strong housing predictions
- **Location**: `projects/07_decision_trees_analysis.py`

### 8. **Bank Dataset Encoding** 🏦
- **Focus**: Data compression & categorical encoding
- **Techniques**: Label encoding, one-hot encoding, ordinal encoding
- **Decision Trees**: Classification on encoded data
- **Performance**: ~88% accuracy
- **Location**: `projects/08_bank_encoding_compression.py`

### 9. **RAG Chatbot System** 🤖
- **Architecture**: PDF processing + Embeddings + Vector search
- **Components**:
  - PDFProcessor: Text extraction & chunking
  - EmbeddingManager: Sentence transformers
  - VectorStoreManager: ChromaDB vector database
  - QueryEngine: Retrieval + LLM inference
- **Use Case**: Document Q&A
- **Location**: `projects/09_rag_chatbot_system.py`

### 10. **Personal Task Manager** ✅
- **AI**: Groq LLM agent integration
- **Features**: Add, list, complete, delete tasks
- **Backend**: Python CLI with persistent storage
- **Use Case**: Intelligent task management
- **Location**: `projects/10_task_manager_groq.py`

### 11. **Brain Tumor Detection** 🧠 ⭐
- **Architecture**: Ensemble (ResNet50 + EfficientNetV2 + ViT)
- **Accuracy**: 99.03% validation, 97.70% test
- **Deployment**: Flask web app + Docker
- **Advanced**: YOLOv11 content filtering
- **Location**: `../brain_tumor_detection/`

---

## 🎯 Key Features

✅ **Diverse ML Techniques**:
- Supervised Learning (Classification, Regression)
- Ensemble Methods (Random Forest, Stacking)
- Deep Learning (CNN, RNN, Transformers)
- NLP & RAG Systems
- Medical AI (Tumor Detection)

✅ **Production-Ready Code**:
- Clean, documented, modular
- Error handling & validation
- Visualization & metrics

✅ **Data Processing**:
- Multiple datasets (MNIST, IMDB, Adult Census, TrashNet, etc.)
- Preprocessing pipelines
- Normalization & encoding strategies

✅ **Advanced Topics**:
- K-Fold Cross-Validation
- Mixed Precision Training (FP16)
- Early Stopping & Callbacks
- Confusion matrices & ROC curves

---

## 📊 Quick Performance Summary

| Project | Model | Accuracy | Status |
|---------|-------|----------|--------|
| SMS Spam | Naive Bayes | 97% | ✅ |
| Waste Classification | CNN | 95% | ✅ |
| Sentiment Analysis | LSTM | 85% | ✅ |
| MNIST | Dense NN | 97% | ✅ |
| Random Forest | RF Classifier | 86% | ✅ |
| Housing Regression | Linear Reg | R²=0.73 | ✅ |
| Decision Trees | DT | 95% (Wine) | ✅ |
| Brain Tumor | Ensemble | **99.03%** | 🏆 |

---

## 🚀 Quick Start

### Installation
```bash
# Clone/download this repository
cd ML_AI_Portfolio

# Install dependencies
pip install -r requirements.txt

# For GPU support (optional)
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
```

### Run Individual Projects
```bash
# SMS Spam Classifier
python projects/01_sms_spam_classifier.py

# Waste Classification
python projects/02_waste_classification_cnn.py

# MNIST Digit Recognition
python projects/04_mnist_digit_recognition.py

# And so on...
```

### Main Dashboard (Coming Soon)
```bash
python main_dashboard.py
# Launches interactive menu to select & run projects
```

---

## 📁 Directory Structure

```
ML_AI_Portfolio/
├── projects/                 # Individual project scripts
│   ├── 01_sms_spam_classifier.py
│   ├── 02_waste_classification_cnn.py
│   ├── 03_sentiment_analysis_rnn.py
│   ├── 04_mnist_digit_recognition.py
│   ├── 05_random_forest_classification.py
│   ├── 06_linear_regression_housing.py
│   ├── 07_decision_trees_analysis.py
│   ├── 08_bank_encoding_compression.py
│   ├── 09_rag_chatbot_system.py
│   └── 10_task_manager_groq.py
├── utils/                    # Shared utilities
│   ├── data_loader.py
│   ├── preprocessing.py
│   ├── metrics.py
│   └── visualization.py
├── data/                     # Datasets & resources
│   ├── datasets.md
│   └── sample_pdfs/
├── results/                  # Generated plots & metrics
├── notebooks/                # Jupyter notebooks (optional)
├── requirements.txt          # Dependencies
├── README.md                 # This file
└── main_dashboard.py         # (Coming) Interactive menu

brain_tumor_detection/        # Separate advanced project
├── app/                      # Flask web app
├── models_v2/                # Ensemble models
├── train_v2.py               # Training script
└── README.md                 # Full documentation
```

---

## 🛠️ Technologies Used

**Core Libraries**:
- TensorFlow/Keras, PyTorch
- Scikit-learn, XGBoost
- Pandas, NumPy, Matplotlib, Seaborn
- OpenCV, Pillow (image processing)

**NLP & AI**:
- Sentence Transformers
- LangChain, ChromaDB
- Transformers (Hugging Face)
- Groq LLM API

**Deployment**:
- Flask, FastAPI (optional)
- Docker
- Streamlit (optional)

---

## 👨‍💻 Developer

**Nagabhushana Raju S**
- Data Scientist & ML Engineer
- Specialization: Deep Learning, Medical AI, NLP
- Email: [your-email]
- LinkedIn: [your-profile]

---

## 📝 License

This portfolio is for **educational and professional use**. Feel free to use for learning, interviews, or portfolio showcasing.

---

## 🎓 Learning Outcomes

After exploring this portfolio, you'll understand:

✅ End-to-end ML pipeline (data → model → evaluation)
✅ Handling different data types (text, images, tabular)
✅ Model selection & hyperparameter tuning
✅ Ensemble methods & stacking
✅ Deep learning architectures (CNN, RNN, Transformers)
✅ NLP & RAG systems
✅ Medical AI applications
✅ Production deployment (Docker, Flask)
✅ Evaluation metrics & visualization

---

**Last Updated**: May 2026
**Total Projects**: 11 (10 mini + 1 advanced)
**Total Lines of Code**: 3000+
**Average Accuracy**: 93%+ across projects

