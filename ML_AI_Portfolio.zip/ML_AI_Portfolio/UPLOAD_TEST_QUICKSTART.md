# QUICK START: Upload & Test Feature

## 🚀 Start Here

### Step 1: Launch Dashboard
```
Double-click: START_DASHBOARD.bat
```
The dashboard window opens with all 10 projects listed.

---

## 📋 Select a Project

Click any project radio button. For example:
- **[04] MNIST Digit Recognition** - Great for testing!

The right panel updates to show project details and accuracy.

---

## ▶️ Launch Project

Click the green **[LAUNCH PROJECT]** button.

A info box appears confirming:
```
[04] MNIST Digit Recognition

Interactive UI opening with:
• Knowledge flow
• Typing animations
• Step-by-step execution
• Real-time console output
```

Click OK.

---

## 👀 Watch Interactive UI

A new window opens showing:

**Left Panel:** KNOWLEDGE FLOW
- Explains what MNIST is
- Text types character-by-character (video effect)
- Shows how the model works

**Right Panel:** EXECUTION PANEL
- [START EXECUTION] button (green)
- Console output area (black/green)
- Progress label

---

## ⚡ Run Execution Steps

Click **[START EXECUTION]**

Watch each step display:
```
[STEP 1] Loading MNIST...
[STEP 2] Building Network...
[STEP 3] Training...
[STEP 4] Results...
[STEP 5] ...
[STEP 6] ...

[COMPLETE] Launching full project...
```

Each step pauses for 2 seconds so you can read.

The actual MNIST project launches in a separate window showing:
- Training progress
- Accuracy metrics
- Visualization plots

---

## ✅ See Completion Popup

When the project finishes, a green **[TASK COMPLETE]** popup appears:

```
┌─────────────────────────────┐
│      [TASK COMPLETE]        │
├─────────────────────────────┤
│                             │
│  [04] MNIST Digit           │
│  Digit Recognition          │
│                             │
│  Model trained successfully!│
│  Accuracy: 97%              │
│                             │
│  Do you want to UPLOAD &    │
│  TEST with your own data?   │
│                             │
│  [YES] [NO]                 │
└─────────────────────────────┘
```

---

## 📤 Upload Custom Data (NEW!)

Click **[YES - UPLOAD & TEST]**

Upload dialog opens showing:

```
┌─────────────────────────┐
│    [UPLOAD & TEST]      │
├─────────────────────────┤
│                         │
│ MNIST Digit:            │
│ Upload 28x28 grayscale  │
│ images (PNG/JPG)        │
│ One digit per image     │
│                         │
│ [ADD FILES]  [TEST]     │
│                         │
│ [No files selected]     │
│                         │
└─────────────────────────┘
```

---

## 📁 Add Files to Test

Click **[ADD FILES]**

File picker opens showing only image types (*.jpg, *.jpeg, *.png).

Select 1 or more digit images from your computer.

Files appear in the list:
```
[No files selected]
↓
digit_5.png
digit_3.jpg
digit_9.png
```

---

## 🧪 Test with Data

Click **[TEST WITH DATA]**

Progress message shows:
```
Testing MNIST Digit Recognition with 3 file(s)...

A detailed report will be generated!

Files:
- digit_5.png
- digit_3.jpg
- digit_9.png
```

---

## 📊 See Test Results

Results window displays:

```
┌─────────────────────────────┐
│     [TEST RESULTS]          │
├─────────────────────────────┤
│                             │
│ [TEST REPORT FOR MNIST...] │
│ ============================│
│                             │
│ Files Processed: 3          │
│ digit_5.png                 │
│ digit_3.jpg                 │
│ digit_9.png                 │
│                             │
│ [RESULTS]                   │
│ Processing Status: COMPLETE │
│ Data Type: Deep Learning    │
│                             │
│ [METRICS]                   │
│ Accuracy: 97%               │
│ Processing Time: <1s        │
│ Data Points: 3              │
│                             │
│ [PREDICTIONS]               │
│ Model applied successfully! │
│                             │
│ [RECOMMENDATIONS]           │
│ ✓ Model performs well       │
│ ✓ Ready for production      │
│ ✓ Consider fine-tuning      │
│                             │
│ [CLOSE]                     │
└─────────────────────────────┘
```

---

## 🎯 Full Feature Overview

### Project Support

All 10 projects support upload & test:

| # | Project | Upload Type | Instructions |
|---|---------|-------------|--------------|
| 1 | SMS Spam | TXT/CSV | Messages (one per line) |
| 2 | Waste CNN | JPG/PNG | Waste images (32x32+) |
| 3 | Sentiment RNN | TXT/CSV | Reviews (one per line) |
| 4 | MNIST | JPG/PNG | 28x28 digit images |
| 5 | Random Forest | CSV | Features (age,income,...) |
| 6 | Housing | CSV | Property data |
| 7 | Decision Trees | CSV | Features |
| 8 | Bank Encoding | CSV | Bank data |
| 9 | RAG Chatbot | TXT/PDF | Documents |
| 10 | Task Manager | JSON/CSV | Task data |

---

## ❌ If No to Upload

Click **[NO - CLOSE]** instead.

The popup closes and you return to the main dashboard.
You can select another project and launch again.

---

## 🔄 Try Another Project

1. Close the interactive launcher window
2. Back to dashboard
3. Select another project (e.g., [02] Waste Classification)
4. Click [LAUNCH PROJECT]
5. Repeat the same flow!

---

## 💡 Tips

- **Fast viewing**: Typing animations default to 0.02s per character. You can read text as it types.
- **Step descriptions**: Each step pauses for 2 seconds. You have time to read before moving to next step.
- **File selection**: File type filters appear based on project type. SMS defaults to TXT/CSV, images default to JPG/PNG.
- **Results**: Test report shows files processed and model accuracy.

---

## ✨ What's New

- **Completion Detection**: Knows when project finishes
- **Popup Overlay**: Asks if you want to test with custom data
- **File Upload**: Browse and select files from your computer
- **Project-Specific Instructions**: Different guidance per project type
- **Test Report**: Summary of processing with metrics

---

## 🎓 Educational Features

The interactive UI teaches through:

1. **Knowledge Flow** → Read what the project does
2. **Step Descriptions** → Learn the process step-by-step
3. **Live Execution** → See code running in console
4. **Typing Animations** → Engages attention
5. **Test Results** → Validates model works on custom data

---

**Ready to try? Double-click START_DASHBOARD.bat!**
