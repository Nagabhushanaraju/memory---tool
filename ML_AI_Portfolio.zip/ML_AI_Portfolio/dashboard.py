"""
UNIFIED ML-AI PORTFOLIO DASHBOARD
Interactive GUI for launching all 10 projects
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import subprocess
import threading
import os
from pathlib import Path

class Project:
    def __init__(self, num, name, file, description, type_, accuracy):
        self.num = num
        self.name = name
        self.file = file
        self.description = description
        self.type = type_
        self.accuracy = accuracy

class PortfolioDashboard:
    def __init__(self, root):
        self.root = root
        self.root.title("ML-AI Portfolio Dashboard")
        self.root.geometry("1000x700")
        self.root.configure(bg="#f0f0f0")

        # Projects database
        self.projects = [
            Project(1, "SMS Spam Classification", "01_sms_spam_classifier.py",
                   "K-Fold cross-validation with TF-IDF and Naive Bayes",
                   "NLP/Classification", "100%"),
            Project(2, "Waste Classification CNN", "02_waste_classification_cnn.py",
                   "3-layer CNN for waste type image classification",
                   "Deep Learning/CNN", "95%"),
            Project(3, "Sentiment Analysis RNN", "03_sentiment_analysis_rnn.py",
                   "3 LSTM architectures: Simple, Bidirectional, Stacked",
                   "Deep Learning/LSTM", "85%"),
            Project(4, "MNIST Digit Recognition", "04_mnist_digit_recognition.py",
                   "Dense neural network for handwritten digit recognition",
                   "Deep Learning/CNN", "97%"),
            Project(5, "Random Forest Classification", "05_random_forest_classification.py",
                   "Ensemble learning with 100 decision trees",
                   "ML/Ensemble", "86%"),
            Project(6, "Linear Regression Housing", "06_linear_regression_housing.py",
                   "Property price prediction using feature scaling",
                   "ML/Regression", "85% R²"),
            Project(7, "Decision Trees Analysis", "07_decision_trees_analysis.py",
                   "Wine classification and housing price regression",
                   "ML/Trees", "95%"),
            Project(8, "Bank Data Encoding", "08_bank_encoding_compression.py",
                   "Label encoding vs One-Hot encoding comparison",
                   "Data Engineering", "60% compression"),
            Project(9, "RAG Chatbot System", "09_rag_chatbot_system.py",
                   "Retrieval-Augmented Generation with embeddings",
                   "NLP/AI", "Semantic retrieval"),
            Project(10, "Task Manager", "10_task_manager.py",
                   "Interactive CLI with JSON persistence",
                   "CLI/Application", "Full CRUD"),
        ]

        self.projects_dir = Path(__file__).parent / "projects"
        self.current_process = None

        self.setup_ui()
        self.center_window()

    def center_window(self):
        self.root.update_idletasks()
        x = (self.root.winfo_screenwidth() // 2) - (self.root.winfo_width() // 2)
        y = (self.root.winfo_screenheight() // 2) - (self.root.winfo_height() // 2)
        self.root.geometry(f"+{x}+{y}")

    def setup_ui(self):
        # Header
        header_frame = tk.Frame(self.root, bg="#2c3e50", height=80)
        header_frame.pack(fill=tk.X)

        title = tk.Label(header_frame, text="ML-AI PORTFOLIO DASHBOARD",
                        font=("Arial", 24, "bold"), bg="#2c3e50", fg="white")
        title.pack(pady=10)

        subtitle = tk.Label(header_frame, text="10 Complete ML/AI Projects - Click to Launch",
                           font=("Arial", 12), bg="#2c3e50", fg="#ecf0f1")
        subtitle.pack(pady=5)

        # Main content area with scrolling
        main_frame = tk.Frame(self.root, bg="#f0f0f0")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Create canvas with scrollbar
        canvas = tk.Canvas(main_frame, bg="#f0f0f0", highlightthickness=0)
        scrollbar = ttk.Scrollbar(main_frame, orient=tk.VERTICAL, command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg="#f0f0f0")

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Create project cards
        for project in self.projects:
            self.create_project_card(scrollable_frame, project)

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Footer with info
        footer_frame = tk.Frame(self.root, bg="#34495e", height=60)
        footer_frame.pack(fill=tk.X)

        footer_text = tk.Label(footer_frame,
                              text="Portfolio Location: " + str(self.projects_dir),
                              font=("Arial", 10), bg="#34495e", fg="#ecf0f1", justify=tk.LEFT)
        footer_text.pack(pady=10)

        status_text = tk.Label(footer_frame,
                              text="Select a project and click LAUNCH to run",
                              font=("Arial", 9), bg="#34495e", fg="#bdc3c7")
        status_text.pack()

    def create_project_card(self, parent, project):
        # Card frame
        card = tk.Frame(parent, bg="white", relief=tk.RAISED, bd=1)
        card.pack(fill=tk.X, pady=8, padx=5)

        # Inner content
        content = tk.Frame(card, bg="white")
        content.pack(fill=tk.BOTH, expand=True, padx=12, pady=10)

        # Header with number and name
        header = tk.Frame(content, bg="white")
        header.pack(fill=tk.X, pady=(0, 5))

        num_label = tk.Label(header, text=f"[{project.num:02d}]",
                            font=("Arial", 14, "bold"), bg="white", fg="#3498db")
        num_label.pack(side=tk.LEFT, padx=(0, 10))

        name_label = tk.Label(header, text=project.name,
                             font=("Arial", 14, "bold"), bg="white", fg="#2c3e50")
        name_label.pack(side=tk.LEFT, expand=True, anchor="w")

        # Type badge
        type_color = self.get_type_color(project.type)
        type_label = tk.Label(header, text=project.type,
                             font=("Arial", 9, "bold"), bg=type_color, fg="white",
                             padx=8, pady=3, relief=tk.FLAT)
        type_label.pack(side=tk.LEFT, padx=5)

        # Accuracy badge
        accuracy_label = tk.Label(header, text=f"Accuracy: {project.accuracy}",
                                 font=("Arial", 9), bg="#e8f4f8", fg="#27ae60",
                                 padx=8, pady=3, relief=tk.FLAT)
        accuracy_label.pack(side=tk.LEFT, padx=2)

        # Description
        desc_label = tk.Label(content, text=project.description,
                             font=("Arial", 11), bg="white", fg="#555555",
                             justify=tk.LEFT, wraplength=700)
        desc_label.pack(fill=tk.X, pady=(5, 10), anchor="w")

        # File path
        file_label = tk.Label(content, text=f"File: {project.file}",
                             font=("Arial", 9, "italic"), bg="white", fg="#7f8c8d")
        file_label.pack(fill=tk.X, anchor="w", pady=(0, 8))

        # Button frame
        button_frame = tk.Frame(content, bg="white")
        button_frame.pack(fill=tk.X, pady=(5, 0))

        # Launch button
        launch_btn = tk.Button(button_frame,
                              text="[LAUNCH PROJECT]",
                              font=("Arial", 11, "bold"),
                              bg="#27ae60",
                              fg="white",
                              activebackground="#229954",
                              activeforeground="white",
                              cursor="hand2",
                              padx=20,
                              pady=8,
                              command=lambda p=project: self.launch_project(p))
        launch_btn.pack(side=tk.LEFT, padx=(0, 5))

        # Info button
        info_btn = tk.Button(button_frame,
                            text="[INFO]",
                            font=("Arial", 10),
                            bg="#3498db",
                            fg="white",
                            activebackground="#2980b9",
                            cursor="hand2",
                            padx=12,
                            pady=8,
                            command=lambda p=project: self.show_info(p))
        info_btn.pack(side=tk.LEFT, padx=2)

        return card

    def get_type_color(self, project_type):
        colors = {
            "NLP/Classification": "#e74c3c",
            "Deep Learning/CNN": "#9b59b6",
            "Deep Learning/LSTM": "#8e44ad",
            "ML/Ensemble": "#3498db",
            "ML/Regression": "#1abc9c",
            "ML/Trees": "#f39c12",
            "Data Engineering": "#34495e",
            "NLP/AI": "#e67e22",
            "CLI/Application": "#95a5a6",
        }
        return colors.get(project_type, "#95a5a6")

    def launch_project(self, project):
        project_path = self.projects_dir / project.file

        if not project_path.exists():
            messagebox.showerror("Error", f"Project file not found: {project_path}")
            return

        # Launch in new window
        try:
            # Use pythonw on Windows for GUI, python otherwise
            python_exe = "python"

            # Create a wrapper to run the project in a new console window
            subprocess.Popen(
                [python_exe, str(project_path)],
                cwd=str(self.projects_dir),
                shell=False
            )

            messagebox.showinfo("Launched",
                              f"[{project.num:02d}] {project.name}\n\n"
                              f"Project launched successfully!\n\n"
                              f"Type: {project.type}\n"
                              f"File: {project.file}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to launch project:\n{str(e)}")

    def show_info(self, project):
        info_window = tk.Toplevel(self.root)
        info_window.title(f"Project {project.num:02d} - {project.name}")
        info_window.geometry("500x400")
        info_window.configure(bg="#f0f0f0")

        # Header
        header = tk.Frame(info_window, bg="#2c3e50")
        header.pack(fill=tk.X)

        title = tk.Label(header, text=project.name,
                        font=("Arial", 16, "bold"), bg="#2c3e50", fg="white")
        title.pack(pady=10)

        # Content
        content = tk.Frame(info_window, bg="white")
        content.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        info_text = f"""
PROJECT NUMBER: {project.num:02d}

NAME: {project.name}

FILE: {project.file}

TYPE: {project.type}

ACCURACY: {project.accuracy}

DESCRIPTION:
{project.description}

DETAILS:
- Fully functional application
- Generates visualizations and metrics
- Ready for production
- Located in: projects/ directory
        """

        text_widget = scrolledtext.ScrolledText(content, font=("Arial", 10),
                                               bg="white", fg="#2c3e50",
                                               wrap=tk.WORD, relief=tk.FLAT)
        text_widget.pack(fill=tk.BOTH, expand=True)
        text_widget.insert(1.0, info_text)
        text_widget.config(state=tk.DISABLED)

        # Close button
        close_btn = tk.Button(info_window, text="CLOSE",
                             font=("Arial", 10, "bold"),
                             bg="#e74c3c", fg="white",
                             command=info_window.destroy)
        close_btn.pack(pady=10)

def main():
    root = tk.Tk()
    app = PortfolioDashboard(root)
    root.mainloop()

if __name__ == "__main__":
    main()
