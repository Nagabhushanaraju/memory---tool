"""
INTERACTIVE PROJECT LAUNCHER WITH TYPING ANIMATIONS & EDUCATIONAL UI
Step-by-step execution with visual learning experience
"""

import tkinter as tk
from tkinter import ttk
import subprocess
import threading
import time
from pathlib import Path

class ProjectLauncher:
    def __init__(self, root, project):
        self.root = root
        self.project = project
        self.root.title(f"[{project['num']:02d}] {project['name']}")
        self.root.geometry("1000x700")
        self.root.configure(bg="#ecf0f1")

        self.setup_ui()
        self.typing_speed = 0.02  # Speed of typing animation

    def setup_ui(self):
        # Header
        header = tk.Frame(self.root, bg="#2c3e50", height=100)
        header.pack(fill=tk.X)

        num_label = tk.Label(header, text=f"[{self.project['num']:02d}]",
                            font=("Arial", 20, "bold"), bg="#2c3e50", fg="#3498db")
        num_label.pack(pady=5)

        title = tk.Label(header, text=self.project['name'],
                        font=("Arial", 18, "bold"), bg="#2c3e50", fg="white")
        title.pack()

        type_label = tk.Label(header, text=self.project['type'],
                             font=("Arial", 11), bg="#2c3e50", fg="#ecf0f1")
        type_label.pack(pady=5)

        # Main content area
        main_frame = tk.Frame(self.root, bg="#ecf0f1")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Left: Educational content
        left_frame = tk.Frame(main_frame, bg="white", relief=tk.RAISED, bd=1)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))

        edu_title = tk.Label(left_frame, text="[KNOWLEDGE FLOW]",
                            font=("Arial", 12, "bold"), bg="white", fg="#2c3e50")
        edu_title.pack(pady=10, padx=10)

        self.edu_text = tk.Text(left_frame, font=("Courier", 10),
                               bg="#f8f9fa", fg="#2c3e50", wrap=tk.WORD,
                               relief=tk.FLAT, padx=10, pady=10)
        self.edu_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        self.edu_text.config(state=tk.DISABLED)

        # Right: Execution panel
        right_frame = tk.Frame(main_frame, bg="white", relief=tk.RAISED, bd=1, width=300)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, padx=(5, 0))
        right_frame.pack_propagate(False)

        exec_title = tk.Label(right_frame, text="[EXECUTION PANEL]",
                             font=("Arial", 12, "bold"), bg="white", fg="#2c3e50")
        exec_title.pack(pady=10, padx=10)

        # Progress area
        self.progress_var = tk.StringVar(value="Ready to start...")
        self.progress_label = tk.Label(right_frame, textvariable=self.progress_var,
                                      font=("Arial", 10), bg="white", fg="#3498db",
                                      wraplength=250, justify=tk.LEFT)
        self.progress_label.pack(pady=10, padx=10, fill=tk.X)

        # Console output
        console_title = tk.Label(right_frame, text="Console Output:",
                                font=("Arial", 9, "bold"), bg="white", fg="#2c3e50")
        console_title.pack(pady=(10, 5), padx=10, anchor=tk.W)

        self.console_text = tk.Text(right_frame, font=("Courier", 8),
                                   bg="#1e1e1e", fg="#00ff00", wrap=tk.WORD,
                                   relief=tk.FLAT, height=15)
        self.console_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        self.console_text.config(state=tk.DISABLED)

        # Button frame
        button_frame = tk.Frame(right_frame, bg="white")
        button_frame.pack(fill=tk.X, padx=10, pady=10)

        self.start_btn = tk.Button(button_frame, text="[START EXECUTION]",
                                  font=("Arial", 11, "bold"),
                                  bg="#27ae60", fg="white",
                                  command=self.start_execution)
        self.start_btn.pack(fill=tk.X, pady=5)

        close_btn = tk.Button(button_frame, text="[CLOSE]",
                             font=("Arial", 10),
                             bg="#e74c3c", fg="white",
                             command=self.root.quit)
        close_btn.pack(fill=tk.X)

        # Display initial knowledge
        self.display_knowledge()

    def display_knowledge(self):
        """Display educational content with typing animation"""
        knowledge = self.get_project_knowledge()
        self.type_text_in_widget(self.edu_text, knowledge)

    def get_project_knowledge(self):
        """Get educational content for each project"""
        knowledge = {
            1: """[WHAT IS SMS SPAM CLASSIFICATION?]

SMS Spam Classification is about detecting whether
a text message is legitimate (ham) or unwanted (spam).

HOW IT WORKS:
1. Convert text into numbers (TF-IDF)
   - Each word gets a numerical value
   - More frequent = higher importance

2. Train a classifier (Naive Bayes)
   - Learn patterns from labeled examples
   - Remember what spam & ham look like

3. Make predictions
   - When new message arrives
   - Predict if it's spam or ham

REAL-WORLD USE:
✓ Email filters
✓ SMS filters
✓ Comment moderation

EXPECTED RESULT:
~100% accuracy on sample data!

WHY THIS MATTERS:
Protects users from phishing, scams,
and unwanted marketing messages.""",

            2: """[WHAT IS WASTE CLASSIFICATION CNN?]

Computer Vision for sorting waste types!
A CNN "sees" images and classifies them.

HOW IT WORKS:
1. Images → Numerical grids (pixels)
   - Each pixel = color value
   - Stack of 3 colors (RGB)

2. Convolution layers
   - Detect edges & patterns
   - Like human eyes learning shapes

3. Pooling layers
   - Compress information
   - Keep important features

4. Dense layers
   - Make final decision
   - Classify waste type

EXAMPLE CATEGORIES:
🔴 Plastic bottles
🟡 Metal cans
🟢 Glass jars
🔵 Cardboard
⚫ Organic waste

PERFORMANCE:
~95% accuracy on validation set!

REAL WORLD:
Automated recycling sorting systems
Waste management optimization""",

            3: """[WHAT IS SENTIMENT ANALYSIS?]

Understand emotions in text!
Does this review show happy or sad feelings?

HOW IT WORKS:
1. Text → Embeddings
   - Convert words to vectors
   - Similar words = similar vectors

2. LSTM Network processes sequence
   - Long Short-Term Memory
   - Remembers context
   - Understands "not bad" vs "bad"

3. Three model types:
   a) Simple LSTM
      - Direct processing

   b) Bidirectional LSTM
      - Reads forward AND backward
      - Better understanding

   c) Stacked LSTM
      - Multiple layers
      - Deeper learning

4. Output: Positive or Negative

REAL APPLICATIONS:
✓ Review sentiment
✓ Tweet analysis
✓ Customer feedback
✓ Social media monitoring

ACCURACY: ~85%

Why LSTM?
Traditional models forget context.
LSTM remembers important words!""",

            4: """[WHAT IS MNIST DIGIT RECOGNITION?]

Teach a computer to read handwritten
digits 0-9, just like humans!

HOW IT WORKS:
1. Input: 28x28 pixel image
   - Grayscale (black & white)
   - 784 total pixels per image

2. Flatten layer
   - Convert 2D image to 1D vector
   - Ready for neural network

3. Hidden layers (Dense)
   - Layer 1: 128 neurons
     Learn basic shapes
   - Layer 2: 64 neurons
     Combine patterns

4. Output layer: 10 neurons
   - One for each digit (0-9)
   - Highest value = prediction

DATASET:
60,000 training images
10,000 test images

ACCURACY: ~97%

APPLICATIONS:
✓ Postal code reading
✓ Bank check processing
✓ Form data entry
✓ Document scanning""",

            5: """[WHAT IS RANDOM FOREST?]

Ensemble Learning: Many trees are
smarter than one tree!

HOW IT WORKS:
1. Create 100 decision trees
   - Each trained on random data subset
   - Each tree makes different decisions

2. Each tree votes
   - Tree 1: "This is Positive"
   - Tree 2: "This is Positive"
   - Tree 3: "This is Negative"
   - Majority wins!

3. Why it works:
   - Different trees catch different patterns
   - Voting reduces errors
   - Generalizes better

COMPARISON:
Single Tree:    75-80% accuracy
Random Forest:  86% accuracy
Ensemble effect = Better results!

FEATURE IMPORTANCE:
Which features matter most?
Age? Education? Occupation?
The model tells us!

REAL WORLD:
✓ Credit scoring
✓ Medical diagnosis
✓ Risk assessment
✓ Fraud detection""",

            6: """[WHAT IS LINEAR REGRESSION?]

Predict numbers using a straight line!
(Or best-fit line through data points)

HOW IT WORKS:
1. Feature Scaling
   - Normalize all inputs
   - Same scale = fair comparison

2. Find the line
   y = m*x + b
   - m = slope (coefficient)
   - b = intercept
   - Minimize error = best fit

3. Coefficient tells story:
   ✓ Positive = increases price
   ✗ Negative = decreases price

EXAMPLE (Housing):
Price = 150*(sq_ft) +
        50000*(bedrooms) +
        30000*(bathrooms) -
        1000*(age)

METRICS:
✓ R² Score (0.85)
  - 85% of variation explained
✓ RMSE (error amount)
✓ MAE (average error)

WHEN TO USE:
✓ Continuous outputs
✓ Linear relationships
✓ Simple & interpretable""",

            7: """[WHAT IS DECISION TREE?]

Tree-based decisions, like flowchart!
If-Then logic computers can learn.

HOW IT WORKS:
1. Root: Best feature to split
   "Is age > 30?"

2. Branches: Yes/No paths
   If age > 30:
   ├─ Check education
   │  ├─ If degree: POSITIVE
   │  └─ If no degree: NEGATIVE
   └─ Check experience...

3. Leaves: Final decisions
   Prediction at the end

WHY IT'S GREAT:
✓ Interpretable
  - Shows reasoning
  - Humans can understand
✓ Handles nonlinear data
✓ Feature importance clear

OVERFITTING ISSUE:
Deep trees memorize data
Solution: Limit depth

REGRESSION VS CLASSIFICATION:
Decision Trees (Classification):
→ Wine type (0, 1, 2)

Decision Trees (Regression):
→ House price ($$$)

ACCURACY: ~95%
Balanced & reliable!""",

            8: """[WHAT IS DATA ENCODING?]

Convert categories to numbers!
Computers need numbers, not text.

HOW IT WORKS:
LABEL ENCODING:
Status → Number
"Single" → 0
"Married" → 1
"Divorced" → 2

Problem: Creates false order!
(1 > 0, 2 > 1 = wrong idea)

ONE-HOT ENCODING:
Status → Binary columns
"Single" → [1, 0, 0]
"Married" → [0, 1, 0]
"Divorced" → [0, 0, 1]

Better for linear/neural models
No false ordering!

TRADE-OFFS:
Label Encoding:
✓ Memory efficient
✓ Tree models like it
✗ Creates ordering

One-Hot Encoding:
✓ No false ordering
✓ Linear models prefer
✗ Uses more memory

COMPRESSION:
Original data: 3.2 KB
After encoding: 1.3 KB
60% reduction achieved!

WHEN TO USE:
Trees → Label Encoding
Linear/Neural → One-Hot""",

            9: """[WHAT IS RAG CHATBOT?]

Retrieval-Augmented Generation
= Search + Answer + Learn

HOW IT WORKS:
1. KNOWLEDGE BASE
   - Store 6 documents
   - Topics: ML, DL, NLP, etc.

2. EMBEDDINGS
   - Convert text to vectors
   - Similar meaning = similar vectors
   - Use cosine similarity to find matches

3. RETRIEVAL
   - User asks question
   - Find 3 most relevant documents
   - Score: "Relevance: 34.6%"

4. GENERATION
   - Pass retrieved docs to LLM
   - Generate answer from context
   - Grounded in knowledge base!

EXAMPLE:
Q: "What is deep learning?"
→ Search knowledge base
→ Find "Deep Learning" document
→ Extract info
→ Generate answer
→ Show relevance score

ADVANTAGES:
✓ Factual (based on documents)
✓ No hallucinations
✓ Traceable sources
✓ Updatable knowledge

REAL WORLD:
✓ Customer support bots
✓ Technical documentation QA
✓ FAQ systems
✓ Internal knowledge bases""",

            10: """[WHAT IS TASK MANAGER?]

Interactive CLI application!
Learn CRUD operations:
Create, Read, Update, Delete

HOW IT WORKS:
1. MENU SYSTEM
   - Interactive choices
   - User-friendly interface

2. CREATE (Add task)
   - Enter description
   - Set deadline
   - Set priority
   - Save to JSON

3. READ (View tasks)
   - List all tasks
   - Filter by status
   - Show statistics

4. UPDATE (Complete task)
   - Mark as done
   - Add completion date
   - Update status

5. DELETE (Remove task)
   - Remove old tasks
   - Clean up database

DATA PERSISTENCE:
- Saves to tasks.json
- Survives program restart
- Easy to backup/transfer

JSON STRUCTURE:
{
  "id": 1,
  "description": "Learn Python",
  "priority": "high",
  "status": "completed",
  "created": "2026-05-04T..."
}

REAL WORLD:
✓ Todo apps
✓ Project management
✓ Personal productivity
✓ Team task tracking"""
        }

        return knowledge.get(self.project['num'], "Project information loading...")

    def type_text_in_widget(self, widget, text):
        """Type text with animation effect"""
        widget.config(state=tk.NORMAL)
        widget.delete(1.0, tk.END)

        def type_animation():
            for char in text:
                widget.insert(tk.END, char)
                widget.see(tk.END)
                widget.update()
                time.sleep(self.typing_speed)

        threading.Thread(target=type_animation, daemon=True).start()

    def type_in_progress(self, text):
        """Type in progress label"""
        self.progress_var.set("")
        for char in text:
            self.progress_var.set(self.progress_var.get() + char)
            self.root.update()
            time.sleep(self.typing_speed)

    def add_console_output(self, text):
        """Add text to console with typing effect"""
        self.console_text.config(state=tk.NORMAL)

        for char in text:
            self.console_text.insert(tk.END, char)
            self.console_text.see(tk.END)
            self.console_text.update()
            time.sleep(0.01)

        self.console_text.config(state=tk.DISABLED)

    def start_execution(self):
        """Start the project execution"""
        self.start_btn.config(state=tk.DISABLED)

        # Show steps with animation
        steps = self.get_execution_steps()

        def run_steps():
            for i, (title, description) in enumerate(steps, 1):
                self.type_in_progress(f"[STEP {i}] {title}...")
                self.add_console_output(f"\n[STEP {i}] {title}\n")
                self.add_console_output(f"{description}\n")
                self.add_console_output("─" * 70 + "\n\n")
                time.sleep(2)  # Pause between steps

            self.add_console_output("\n[COMPLETE] Launching project...\n")
            self.type_in_progress("Execution complete! Opening full console...")
            time.sleep(2)

            # Launch actual project
            self.launch_project()

        threading.Thread(target=run_steps, daemon=True).start()

    def get_execution_steps(self):
        """Get execution steps for each project"""
        steps = {
            1: [
                ("Loading Data", "Reading SMS dataset with 100 messages..."),
                ("Vectorization", "Converting text to TF-IDF vectors..."),
                ("K-Fold Setup", "Creating 5 cross-validation folds..."),
                ("Model Training", "Training Naive Bayes on each fold..."),
                ("ROC Curve", "Generating ROC curve analysis..."),
                ("Results", "Displaying accuracy and AUC scores..."),
            ],
            2: [
                ("Loading Dataset", "Loading CIFAR-10 with 60,000 images..."),
                ("Preprocessing", "Normalizing pixel values 0-1..."),
                ("Building CNN", "Creating 3-layer convolutional network..."),
                ("Data Augmentation", "Rotating, flipping images for variety..."),
                ("Training", "Training for 3 epochs with validation..."),
                ("Evaluation", "Testing on 10,000 unseen images..."),
            ],
            3: [
                ("Loading IMDB Data", "Reading 50,000 movie reviews..."),
                ("Padding Sequences", "Normalizing all to 100 tokens..."),
                ("Building Model 1", "Creating Simple LSTM..."),
                ("Building Model 2", "Creating Bidirectional LSTM..."),
                ("Building Model 3", "Creating Stacked LSTM..."),
                ("Training & Evaluation", "Comparing all 3 models..."),
            ],
            4: [
                ("Loading MNIST", "Reading 70,000 handwritten digits..."),
                ("Preprocessing", "Flattening 28x28 images to 784 features..."),
                ("Building Network", "Dense layers: 784→128→64→10..."),
                ("Training", "Training 5 epochs with validation split..."),
                ("Testing", "Evaluating on 10,000 test images..."),
                ("Prediction Viz", "Showing sample predictions..."),
            ],
            5: [
                ("Generate Data", "Creating 200 synthetic samples..."),
                ("Split Data", "80% train, 20% test split..."),
                ("Train Single Tree", "Building decision tree baseline..."),
                ("Train Random Forest", "Building ensemble of 100 trees..."),
                ("Feature Analysis", "Calculating importance scores..."),
                ("Comparison", "Showing accuracy comparison..."),
            ],
            6: [
                ("Generate Data", "Creating 200 synthetic properties..."),
                ("Feature Scaling", "Normalizing all features..."),
                ("Train Model", "Linear regression fit..."),
                ("Predictions", "Making price predictions..."),
                ("Metrics", "Calculating R², RMSE, MAE..."),
                ("Visualization", "Creating regression plots..."),
            ],
            7: [
                ("Load Wine Data", "Reading 178 wine samples..."),
                ("Generate Housing Data", "Creating 200 properties..."),
                ("Train Wine Tree", "Building classification tree..."),
                ("Train Housing Tree", "Building regression tree..."),
                ("Feature Importance", "Analyzing feature contributions..."),
                ("Visualization", "Drawing tree structures..."),
            ],
            8: [
                ("Generate Data", "Creating 500 customer records..."),
                ("Label Encoding", "Converting text to integers..."),
                ("One-Hot Encoding", "Creating binary features..."),
                ("Memory Analysis", "Comparing compression ratios..."),
                ("Distribution", "Analyzing categorical features..."),
                ("Visualization", "Creating comparison charts..."),
            ],
            9: [
                ("Initialize", "Setting up embedding system..."),
                ("Add Documents", "Storing 6 knowledge documents..."),
                ("Test Retrieval", "Searching for similar documents..."),
                ("Chat Session", "Running interactive demo..."),
                ("Analysis", "Computing relevance scores..."),
                ("Save Results", "Storing conversation log..."),
            ],
            10: [
                ("Initialize", "Setting up task manager..."),
                ("Display Menu", "Showing interactive options..."),
                ("Add Task", "Creating sample task..."),
                ("List Tasks", "Displaying all tasks..."),
                ("Complete Task", "Marking task as done..."),
                ("Statistics", "Showing task metrics..."),
            ],
        }

        return steps.get(self.project['num'], [])

    def launch_project(self):
        """Launch the actual project in terminal"""
        projects_dir = Path(__file__).parent / "projects"
        project_path = projects_dir / self.project['file']

        try:
            subprocess.Popen(
                ["python", str(project_path)],
                cwd=str(projects_dir),
                shell=False
            )
        except Exception as e:
            self.add_console_output(f"\nError: {str(e)}\n")

def create_project_window(project):
    """Create window for a single project"""
    root = tk.Tk()
    app = ProjectLauncher(root, project)
    root.mainloop()

# Example: Can be called from dashboard
if __name__ == "__main__":
    sample_project = {
        "num": 4,
        "name": "MNIST Digit Recognition",
        "file": "04_mnist_digit_recognition.py",
        "type": "Deep Learning"
    }

    create_project_window(sample_project)
