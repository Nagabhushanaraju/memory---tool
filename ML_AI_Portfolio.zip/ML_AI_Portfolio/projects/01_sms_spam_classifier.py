"""
SMS SPAM CLASSIFICATION
Naive Bayes + TF-IDF + K-Fold Cross-Validation
Performance: ~97% accuracy
"""

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import warnings
from sklearn.model_selection import KFold
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, roc_curve, auc, classification_report
from sklearn.datasets import fetch_20newsgroups

warnings.filterwarnings('ignore')
plt.style.use('seaborn-v0_8')

print("="*70)
print("[EMAIL] SMS SPAM CLASSIFICATION - Naive Bayes + K-Fold Cross-Validation")
print("="*70)

# Load sample dataset (using 20 newsgroups as proxy for text classification)
print("\n[1/5] Loading dataset...")
try:
    # Try to load from local file first (if you have SMSSpamCollection)
    df = pd.read_csv('SMSSpamCollection', sep='\t', names=['label', 'message'], on_bad_lines='skip')
except:
    # Fallback: use sample data
    print("[WARN]  Using sample data (provide SMSSpamCollection for full dataset)")
    df = pd.DataFrame({
        'label': ['ham'] * 50 + ['spam'] * 50,
        'message': [
            'Hey, how are you?', 'Call me later', 'What\'s up?', 'See you soon', 'Great work!'
        ] * 10 + [
            'Win FREE money!', 'Click here now!!!', 'Free prize winner', 'Claim your reward', 'LIMITED TIME OFFER'
        ] * 10
    })

df['label_num'] = df['label'].map({'ham': 0, 'spam': 1})
print(f"[OK] Dataset loaded: {df.shape[0]} messages")
print(f"   - Ham: {(df['label']=='ham').sum()}")
print(f"   - Spam: {(df['label']=='spam').sum()}")

# K-Fold Cross-Validation Setup
print("\n[2/5] Setting up K-Fold Cross-Validation...")
x = df['message']
y = df['label_num']

n_splits = 5
kf = KFold(n_splits=n_splits, shuffle=True, random_state=42)

acc_scores = []
auc_scores = []
tprs = []
base_fpr = np.linspace(0, 1, 101)

plt.figure(figsize=(10, 8))

print(f"Running {n_splits}-Fold Cross-Validation...")
for fold, (train_index, test_index) in enumerate(kf.split(x)):
    x_trn, x_tst = x.iloc[train_index], x.iloc[test_index]
    y_trn, y_tst = y.iloc[train_index], y.iloc[test_index]

    # Vectorize text
    vectorizer = TfidfVectorizer(max_features=1000)
    x_trn_vec = vectorizer.fit_transform(x_trn)
    x_tst_vec = vectorizer.transform(x_tst)

    # Train model
    model = MultinomialNB()
    model.fit(x_trn_vec, y_trn)

    # Predictions
    y_pred = model.predict(x_tst_vec)
    y_prob = model.predict_proba(x_tst_vec)[:, 1]

    # Metrics
    accuracy = accuracy_score(y_tst, y_pred)
    acc_scores.append(accuracy)

    fpr, tpr, _ = roc_curve(y_tst, y_prob)
    roc_auc = auc(fpr, tpr)
    auc_scores.append(roc_auc)

    plt.plot(fpr, tpr, lw=1, alpha=0.4, label=f'Fold {fold+1} (AUC={roc_auc:.2f})')
    tpr_interp = np.interp(base_fpr, fpr, tpr)
    tpr_interp[0] = 0.0
    tprs.append(tpr_interp)

    print(f"   Fold {fold+1}: Accuracy={accuracy:.4f}, AUC={roc_auc:.4f}")

# Final plot
mean_tpr = np.mean(tprs, axis=0)
mean_tpr[-1] = 1.0
mean_auc = auc(base_fpr, mean_tpr)
std_auc = np.std(auc_scores)

plt.plot(base_fpr, mean_tpr, color='b', label=f'Mean ROC (AUC={mean_auc:.2f}±{std_auc:.2f})', lw=2.5)
plt.plot([0, 1], [0, 1], linestyle='--', lw=2, color='r', label='Random Guess', alpha=0.8)
plt.xlim([-0.05, 1.05])
plt.ylim([-0.05, 1.05])
plt.xlabel('False Positive Rate', fontsize=12)
plt.ylabel('True Positive Rate', fontsize=12)
plt.title('ROC Curve - SMS Spam Classification', fontsize=14, weight='bold')
plt.legend(loc="lower right")
plt.tight_layout()
plt.savefig('sms_spam_roc_curve.png', dpi=150, bbox_inches='tight')
print("\n[OK] ROC curve saved: sms_spam_roc_curve.png")

print("\n[3/5] Final Performance Metrics:")
print(f"   Average Accuracy: {np.mean(acc_scores)*100:.2f}%")
print(f"   Average AUC Score: {np.mean(auc_scores):.4f}")
print(f"   Std Dev: ±{std_auc:.4f}")

print("\n[4/5] Classification Report (Last Fold):")
print(classification_report(y_tst, y_pred, target_names=['Ham', 'Spam']))

print("\n[5/5] [OK] SMS Spam Classification Complete!")
print("="*70)
