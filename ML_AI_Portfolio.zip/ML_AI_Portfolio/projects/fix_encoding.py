import os
import re

files = [
    '02_waste_classification_cnn.py',
    '03_sentiment_analysis_rnn.py',
    '06_linear_regression_housing.py',
    '07_decision_trees_analysis.py',
    '08_bank_encoding_compression.py',
    '09_rag_chatbot_system.py'
]

emoji_map = {
    '♻️': '[RECYCLE]',
    '🏠': '[HOUSE]',
    '💬': '[CHAT]',
    '🤖': '[ROBOT]',
    '🔢': '[DIGIT]',
    '🌲': '[TREE]',
    '📧': '[EMAIL]',
    '🔮': '[MAGIC]',
    '💾': '[SAVE]',
    '📊': '[CHART]',
    '📈': '[GRAPH]',
    '✅': '[OK]',
    '❌': '[FAIL]',
    '⏸️': '[PAUSE]',
    '⚠️': '[WARN]',
    '🔋': '[BATTERY]',
    '📦': '[PACKAGE]',
    '🏦': '[BANK]',
    '🔢': '[NUM]'
}

for filename in files:
    if os.path.exists(filename):
        with open(filename, 'r', encoding='utf-8') as f:
            content = f.read()
        
        for emoji, text in emoji_map.items():
            content = content.replace(emoji, text)
        
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(content)
        
        print(f"Fixed: {filename}")

print("\nAll files updated!")
