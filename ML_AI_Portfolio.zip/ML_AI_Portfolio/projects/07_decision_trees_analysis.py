"""
DECISION TREES ANALYSIS
Wine & Housing Datasets - Tree-based Classification & Regression
Performance: ~95% accuracy (wine), ~0.85 R² (housing)
"""

import numpy as np
import pandas as pd
from sklearn.datasets import load_wine
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor, plot_tree
from sklearn.metrics import accuracy_score, classification_report, r2_score, mean_squared_error
import matplotlib.pyplot as plt
import seaborn as sns

print("="*70)
print("🌳 DECISION TREES ANALYSIS - Wine & Housing")
print("="*70)

# ==================== PART 1: Wine Classification ====================
print("\n" + "="*70)
print("Part 1: WINE CLASSIFICATION")
print("="*70)

print("\n[1/4] Loading wine dataset...")
wine_data = load_wine()
X_wine = pd.DataFrame(wine_data.data, columns=wine_data.feature_names)
y_wine = wine_data.target

print(f"[OK] Dataset loaded: {X_wine.shape[0]} samples, {X_wine.shape[1]} features")
print(f"   Classes: {np.unique(y_wine)} (Wine cultivars 0, 1, 2)")
print(f"   Features: {', '.join(X_wine.columns[:3])}... (13 total)")

# Split data
X_trn_wine, X_tst_wine, y_trn_wine, y_tst_wine = train_test_split(
    X_wine, y_wine, test_size=0.2, random_state=42
)

print("\n[2/4] Training Decision Tree (wine classification)...")
dt_wine = DecisionTreeClassifier(max_depth=5, random_state=42, min_samples_split=5)
dt_wine.fit(X_trn_wine, y_trn_wine)

y_pred_wine = dt_wine.predict(X_tst_wine)
acc_wine = accuracy_score(y_tst_wine, y_pred_wine)

print(f"[OK] Model trained")
print(f"   Test Accuracy: {acc_wine*100:.2f}%")
print(f"   Tree Depth: {dt_wine.get_depth()}")
print(f"   Leaves: {dt_wine.get_n_leaves()}")

# Feature importance (wine)
feature_imp_wine = pd.DataFrame({
    'feature': X_wine.columns,
    'importance': dt_wine.feature_importances_
}).sort_values('importance', ascending=False)

print("\n   Top 5 Important Features:")
for idx, row in feature_imp_wine.head(5).iterrows():
    print(f"     {row['feature']:25} : {row['importance']:.4f}")

print("\n[3/4] Classification Report (Wine):")
print(classification_report(y_tst_wine, y_pred_wine,
      target_names=['Cultivar 0', 'Cultivar 1', 'Cultivar 2']))

# ==================== PART 2: Housing Regression ====================
print("\n" + "="*70)
print("Part 2: HOUSING PRICE REGRESSION")
print("="*70)

print("\n[1/3] Creating housing dataset...")
np.random.seed(42)
n_samples = 200

housing_data = {
    'square_feet': np.random.uniform(800, 4000, n_samples),
    'bedrooms': np.random.randint(1, 6, n_samples),
    'bathrooms': np.random.randint(1, 4, n_samples),
    'age': np.random.randint(0, 50, n_samples),
}

X_housing = pd.DataFrame(housing_data)
y_housing = (
    X_housing['square_feet'] * 150 +
    X_housing['bedrooms'] * 50000 +
    X_housing['bathrooms'] * 30000 +
    X_housing['age'] * (-1000) +
    np.random.normal(0, 50000, n_samples)
)

print(f"[OK] Dataset created: {X_housing.shape[0]} properties, {X_housing.shape[1]} features")

# Split data
X_trn_housing, X_tst_housing, y_trn_housing, y_tst_housing = train_test_split(
    X_housing, y_housing, test_size=0.2, random_state=42
)

print("\n[2/3] Training Decision Tree (housing regression)...")
dt_housing = DecisionTreeRegressor(max_depth=5, random_state=42, min_samples_split=5)
dt_housing.fit(X_trn_housing, y_trn_housing)

y_pred_housing = dt_housing.predict(X_tst_housing)
r2_housing = r2_score(y_tst_housing, y_pred_housing)
rmse_housing = np.sqrt(mean_squared_error(y_tst_housing, y_pred_housing))

print(f"[OK] Model trained")
print(f"   Test R² Score: {r2_housing:.4f}")
print(f"   Test RMSE: ${rmse_housing:,.2f}")
print(f"   Tree Depth: {dt_housing.get_depth()}")
print(f"   Leaves: {dt_housing.get_n_leaves()}")

# Feature importance (housing)
feature_imp_housing = pd.DataFrame({
    'feature': X_housing.columns,
    'importance': dt_housing.feature_importances_
}).sort_values('importance', ascending=False)

print("\n   Feature Importance:")
for idx, row in feature_imp_housing.iterrows():
    print(f"     {row['feature']:15} : {row['importance']:.4f}")

# ==================== VISUALIZATIONS ====================
print("\n[3/4] Creating visualizations...")

fig = plt.figure(figsize=(18, 12))

# 1. Wine Tree Visualization
ax1 = plt.subplot(2, 2, 1)
plot_tree(dt_wine, feature_names=X_wine.columns, class_names=wine_data.target_names,
         filled=True, ax=ax1, fontsize=8, max_depth=3)
ax1.set_title(f'Wine Classification Tree (Accuracy: {acc_wine*100:.2f}%)', fontsize=12, weight='bold')

# 2. Wine Feature Importance
ax2 = plt.subplot(2, 2, 2)
top_features_wine = feature_imp_wine.head(8)
ax2.barh(top_features_wine['feature'], top_features_wine['importance'], color='steelblue', alpha=0.7)
ax2.set_xlabel('Importance')
ax2.set_title('Wine: Top 8 Feature Importance', fontsize=12, weight='bold')
ax2.grid(True, alpha=0.3, axis='x')

# 3. Housing Tree Visualization
ax3 = plt.subplot(2, 2, 3)
plot_tree(dt_housing, feature_names=X_housing.columns,
         filled=True, ax=ax3, fontsize=10, max_depth=2)
ax3.set_title(f'Housing Regression Tree (R²: {r2_housing:.4f})', fontsize=12, weight='bold')

# 4. Housing Predictions vs Actual
ax4 = plt.subplot(2, 2, 4)
ax4.scatter(y_tst_housing, y_pred_housing, alpha=0.6, s=50, color='coral')
ax4.plot([y_tst_housing.min(), y_tst_housing.max()],
        [y_tst_housing.min(), y_tst_housing.max()],
        'r--', lw=2, label='Perfect Fit')
ax4.set_xlabel('Actual Price ($)')
ax4.set_ylabel('Predicted Price ($)')
ax4.set_title(f'Housing: Actual vs Predicted', fontsize=12, weight='bold')
ax4.legend()
ax4.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('decision_trees_analysis.png', dpi=150, bbox_inches='tight')
print("[OK] Tree visualizations saved: decision_trees_analysis.png")

# ==================== SUMMARY ====================
fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Wine Summary
wine_summary = f"""
[WINE] WINE CLASSIFICATION SUMMARY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Samples: {X_wine.shape[0]}
Features: {X_wine.shape[1]}
Classes: 3 (Wine cultivars)

Train/Test Split: 80/20
Test Accuracy: {acc_wine*100:.2f}%

Tree Metrics:
  • Max Depth: {dt_wine.get_depth()}
  • Leaf Nodes: {dt_wine.get_n_leaves()}
  • Split Criterion: Gini

Top 3 Features:
  1. {feature_imp_wine.iloc[0]['feature']}
  2. {feature_imp_wine.iloc[1]['feature']}
  3. {feature_imp_wine.iloc[2]['feature']}
"""

axes[0].axis('off')
axes[0].text(0.05, 0.95, wine_summary, transform=axes[0].transAxes,
            fontfamily='monospace', fontsize=10, verticalalignment='top',
            bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.3))

# Housing Summary
housing_summary = f"""
[HOUSE] HOUSING REGRESSION SUMMARY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Samples: {X_housing.shape[0]}
Features: {X_housing.shape[1]}
Target: Price prediction

Train/Test Split: 80/20
Test R² Score: {r2_housing:.4f}
Test RMSE: ${rmse_housing:,.0f}

Tree Metrics:
  • Max Depth: {dt_housing.get_depth()}
  • Leaf Nodes: {dt_housing.get_n_leaves()}
  • Split Criterion: MSE

Feature Importance:
  1. {feature_imp_housing.iloc[0]['feature']}
  2. {feature_imp_housing.iloc[1]['feature']}
  3. {feature_imp_housing.iloc[2]['feature']}
"""

axes[1].axis('off')
axes[1].text(0.05, 0.95, housing_summary, transform=axes[1].transAxes,
            fontfamily='monospace', fontsize=10, verticalalignment='top',
            bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.3))

plt.tight_layout()
plt.savefig('decision_trees_summary.png', dpi=150, bbox_inches='tight')
print("[OK] Summary saved: decision_trees_summary.png")

print("\n" + "="*70)
print("[DONE] Decision Trees Analysis Complete!")
print("="*70)
