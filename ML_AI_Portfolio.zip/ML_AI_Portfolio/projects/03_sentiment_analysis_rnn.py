"""
SENTIMENT ANALYSIS - IMDB REVIEWS
3 RNN Architectures (LSTM, Bidirectional LSTM, Stacked LSTM)
Performance: ~85% accuracy
"""

import numpy as np
from tensorflow.keras.datasets import imdb
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense, Dropout, Bidirectional
from tensorflow.keras.optimizers import Adam
import matplotlib.pyplot as plt
import warnings

warnings.filterwarnings('ignore')

print("="*70)
print("[CHAT] SENTIMENT ANALYSIS - IMDB Reviews (3 LSTM Models)")
print("="*70)

# Load IMDB dataset
print("\n[1/6] Loading IMDB dataset...")
vocab_size = 10000
max_length = 100

(x_trn, y_trn), (x_tst, y_tst) = imdb.load_data(num_words=vocab_size)
print(f"[OK] Dataset loaded: {len(x_trn)} training, {len(x_tst)} test samples")

# Pad sequences
print("\n[2/6] Preprocessing sequences...")
x_trn = pad_sequences(x_trn, maxlen=max_length, padding='post')
x_tst = pad_sequences(x_tst, maxlen=max_length, padding='post')
print(f"[OK] Sequences padded to {max_length} tokens")
print(f"   Reviews: positive=1, negative=0")

# Model 1: Simple LSTM
print("\n[3/6] Building Model 1: Simple LSTM...")
model1 = Sequential([
    Embedding(vocab_size, 64, input_length=max_length),
    LSTM(64, return_sequences=False),
    Dropout(0.2),
    Dense(32, activation='relu'),
    Dense(1, activation='sigmoid')
])
model1.compile(optimizer=Adam(learning_rate=0.001), loss='binary_crossentropy', metrics=['accuracy'])
print("[OK] Architecture: Embedding → LSTM(64) → Dropout → Dense(32) → Dense(1)")

# Model 2: Bidirectional LSTM
print("\n[4/6] Building Model 2: Bidirectional LSTM...")
model2 = Sequential([
    Embedding(vocab_size, 64, input_length=max_length),
    Bidirectional(LSTM(64, return_sequences=False)),
    Dropout(0.2),
    Dense(32, activation='relu'),
    Dense(1, activation='sigmoid')
])
model2.compile(optimizer=Adam(learning_rate=0.001), loss='binary_crossentropy', metrics=['accuracy'])
print("[OK] Architecture: Embedding → BiLSTM(64) → Dropout → Dense(32) → Dense(1)")

# Model 3: Stacked LSTM
print("\n[5/6] Building Model 3: Stacked LSTM...")
model3 = Sequential([
    Embedding(vocab_size, 64, input_length=max_length),
    LSTM(64, return_sequences=True),
    Dropout(0.2),
    LSTM(32, return_sequences=False),
    Dropout(0.2),
    Dense(32, activation='relu'),
    Dense(1, activation='sigmoid')
])
model3.compile(optimizer=Adam(learning_rate=0.001), loss='binary_crossentropy', metrics=['accuracy'])
print("[OK] Architecture: Embedding → LSTM(64) → LSTM(32) → Dropout → Dense(32) → Dense(1)")

# Training
print("\n[6/6] Training all 3 models (3 epochs each)...\n")

print("🔄 Model 1: Simple LSTM")
history1 = model1.fit(x_trn, y_trn, epochs=3, batch_size=64,
                     validation_split=0.2, verbose=0)
test_acc1 = model1.evaluate(x_tst, y_tst, verbose=0)[1]
print(f"[OK] Test Accuracy: {test_acc1*100:.2f}%")

print("\n🔄 Model 2: Bidirectional LSTM")
history2 = model2.fit(x_trn, y_trn, epochs=3, batch_size=64,
                     validation_split=0.2, verbose=0)
test_acc2 = model2.evaluate(x_tst, y_tst, verbose=0)[1]
print(f"[OK] Test Accuracy: {test_acc2*100:.2f}%")

print("\n🔄 Model 3: Stacked LSTM")
history3 = model3.fit(x_trn, y_trn, epochs=3, batch_size=64,
                     validation_split=0.2, verbose=0)
test_acc3 = model3.evaluate(x_tst, y_tst, verbose=0)[1]
print(f"[OK] Test Accuracy: {test_acc3*100:.2f}%")

# Sample predictions
print("\nGenerating predictions on test samples...")
pred1 = (model1.predict(x_tst[:5], verbose=0) > 0.5).flatten()
pred2 = (model2.predict(x_tst[:5], verbose=0) > 0.5).flatten()
pred3 = (model3.predict(x_tst[:5], verbose=0) > 0.5).flatten()
true = y_tst[:5]

# Visualizations
fig, axes = plt.subplots(2, 3, figsize=(16, 10))

# Model 1: Training history
axes[0, 0].plot(history1.history['accuracy'], label='Train', linewidth=2)
axes[0, 0].plot(history1.history['val_accuracy'], label='Validation', linewidth=2)
axes[0, 0].set_title(f'Model 1: Simple LSTM\nTest Acc: {test_acc1*100:.2f}%')
axes[0, 0].set_xlabel('Epoch')
axes[0, 0].set_ylabel('Accuracy')
axes[0, 0].legend()
axes[0, 0].grid(True, alpha=0.3)

# Model 2: Training history
axes[0, 1].plot(history2.history['accuracy'], label='Train', linewidth=2)
axes[0, 1].plot(history2.history['val_accuracy'], label='Validation', linewidth=2)
axes[0, 1].set_title(f'Model 2: Bidirectional LSTM\nTest Acc: {test_acc2*100:.2f}%')
axes[0, 1].set_xlabel('Epoch')
axes[0, 1].set_ylabel('Accuracy')
axes[0, 1].legend()
axes[0, 1].grid(True, alpha=0.3)

# Model 3: Training history
axes[0, 2].plot(history3.history['accuracy'], label='Train', linewidth=2)
axes[0, 2].plot(history3.history['val_accuracy'], label='Validation', linewidth=2)
axes[0, 2].set_title(f'Model 3: Stacked LSTM\nTest Acc: {test_acc3*100:.2f}%')
axes[0, 2].set_xlabel('Epoch')
axes[0, 2].set_ylabel('Accuracy')
axes[0, 2].legend()
axes[0, 2].grid(True, alpha=0.3)

# Loss comparison
axes[1, 0].plot(history1.history['loss'], label='Train', linewidth=2)
axes[1, 0].plot(history1.history['val_loss'], label='Validation', linewidth=2)
axes[1, 0].set_title('Model 1: Loss')
axes[1, 0].set_xlabel('Epoch')
axes[1, 0].set_ylabel('Loss')
axes[1, 0].legend()
axes[1, 0].grid(True, alpha=0.3)

# Loss comparison
axes[1, 1].plot(history2.history['loss'], label='Train', linewidth=2)
axes[1, 1].plot(history2.history['val_loss'], label='Validation', linewidth=2)
axes[1, 1].set_title('Model 2: Loss')
axes[1, 1].set_xlabel('Epoch')
axes[1, 1].set_ylabel('Loss')
axes[1, 1].legend()
axes[1, 1].grid(True, alpha=0.3)

# Loss comparison
axes[1, 2].plot(history3.history['loss'], label='Train', linewidth=2)
axes[1, 2].plot(history3.history['val_loss'], label='Validation', linewidth=2)
axes[1, 2].set_title('Model 3: Loss')
axes[1, 2].set_xlabel('Epoch')
axes[1, 2].set_ylabel('Loss')
axes[1, 2].legend()
axes[1, 2].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('sentiment_analysis_lstm.png', dpi=150, bbox_inches='tight')
print("[OK] Training history saved: sentiment_analysis_lstm.png")

# Model comparison
print("\n[CHART] MODEL COMPARISON:")
models_data = {
    'Simple LSTM': test_acc1*100,
    'Bidirectional': test_acc2*100,
    'Stacked LSTM': test_acc3*100
}

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

# Bar chart
colors = ['#3498db', '#e74c3c', '#2ecc71']
ax1.bar(models_data.keys(), models_data.values(), color=colors, alpha=0.8)
ax1.set_title('Test Accuracy Comparison', fontsize=14, weight='bold')
ax1.set_ylabel('Accuracy (%)')
ax1.set_ylim([70, 100])
for i, (model, acc) in enumerate(models_data.items()):
    ax1.text(i, acc+1, f'{acc:.2f}%', ha='center', fontweight='bold')

# Predictions
pred_text = "[MAGIC] Sample Predictions (First 5 test samples):\n\n"
sentiment = {0: 'Negative', 1: 'Positive'}
for i in range(5):
    true_sent = sentiment[true[i]]
    match1 = "[OK]" if pred1[i] == true[i] else "[FAIL]"
    match2 = "[OK]" if pred2[i] == true[i] else "[FAIL]"
    match3 = "[OK]" if pred3[i] == true[i] else "[FAIL]"
    pred_text += f"Sample {i+1}: True={true_sent}\n"
    pred_text += f"  {match1} Model1: {sentiment[pred1[i]]} | "
    pred_text += f"{match2} Model2: {sentiment[pred2[i]]} | "
    pred_text += f"{match3} Model3: {sentiment[pred3[i]]}\n\n"

ax2.axis('off')
ax2.text(0.05, 0.95, pred_text, transform=ax2.transAxes,
         fontfamily='monospace', fontsize=10, verticalalignment='top')

plt.tight_layout()
plt.savefig('sentiment_analysis_comparison.png', dpi=150, bbox_inches='tight')
print("[OK] Comparison saved: sentiment_analysis_comparison.png")

print("\n" + "="*70)
print("[DONE] Sentiment Analysis Complete!")
print("="*70)
