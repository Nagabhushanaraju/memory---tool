"""
MNIST DIGIT RECOGNITION
Dense Neural Network with TensorFlow/Keras
Performance: ~97% test accuracy
"""

import tensorflow as tf
from tensorflow.keras.datasets import mnist
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Flatten
from tensorflow.keras.utils import to_categorical
import matplotlib.pyplot as plt
import numpy as np

print("="*70)
print("[DIGIT] MNIST DIGIT RECOGNITION - Dense Neural Network")
print("="*70)

# Load MNIST dataset
print("\n[1/5] Loading MNIST dataset...")
(x_trn, y_trn), (x_tst, y_tst) = mnist.load_data()
print(f"[OK] Training images: {len(x_trn)}, Test images: {len(x_tst)}")

# Preprocess data
print("\n[2/5] Preprocessing data...")
x_trn = x_trn.reshape((60000, 28*28)).astype('float32') / 255
x_tst = x_tst.reshape((10000, 28*28)).astype('float32') / 255
y_trn = to_categorical(y_trn, 10)
y_tst = to_categorical(y_tst, 10)
print(f"[OK] Data normalized and reshaped")

# Build model
print("\n[3/5] Building neural network...")
model = Sequential([
    Flatten(input_shape=(784,)),
    Dense(128, activation='relu'),
    Dense(64, activation='relu'),
    Dense(10, activation='softmax')
])
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
print("[OK] Model architecture:")
model.summary()

# Train model
print("\n[4/5] Training model (5 epochs)...")
history = model.fit(x_trn, y_trn, epochs=5, batch_size=128, validation_split=0.2, verbose=1)

# Evaluate
print("\n[5/5] Evaluating performance...")
test_loss, test_acc = model.evaluate(x_tst, y_tst)
print(f"\n[OK] Test Accuracy: {test_acc*100:.2f}%")
print(f"[OK] Test Loss: {test_loss:.4f}")

# Plot training history
plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'], label='Train Accuracy')
plt.plot(history.history['val_accuracy'], label='Val Accuracy')
plt.title('Model Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Train Loss')
plt.plot(history.history['val_loss'], label='Val Loss')
plt.title('Model Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()
plt.tight_layout()
plt.savefig('mnist_training_history.png', dpi=150, bbox_inches='tight')
print("[OK] Training history saved: mnist_training_history.png")

# Make predictions on test set
print("\nMaking predictions on sample images...")
predictions = model.predict(x_tst[:9])
pred_labels = np.argmax(predictions, axis=1)
true_labels = np.argmax(y_tst[:9], axis=1)

plt.figure(figsize=(10, 10))
for i in range(9):
    plt.subplot(3, 3, i+1)
    plt.imshow(x_tst[i].reshape(28, 28), cmap='gray')
    color = 'green' if pred_labels[i] == true_labels[i] else 'red'
    plt.title(f'True: {true_labels[i]}, Pred: {pred_labels[i]}', color=color)
    plt.axis('off')
plt.tight_layout()
plt.savefig('mnist_predictions.png', dpi=150, bbox_inches='tight')
print("[OK] Predictions saved: mnist_predictions.png")

print("\n" + "="*70)
print("[DONE] MNIST Digit Recognition Complete!")
print("="*70)
