"""
PERSONAL TASK MANAGER
AI-Powered Task Management System
Features: Add, List, Complete, Delete Tasks
"""

import json
import os
from datetime import datetime

class TaskManager:
    def __init__(self, storage_file='tasks.json'):
        self.storage_file = storage_file
        self.tasks = self.load_tasks()

    def load_tasks(self):
        """Load tasks from JSON file"""
        if os.path.exists(self.storage_file):
            try:
                with open(self.storage_file, 'r') as f:
                    return json.load(f)
            except:
                return []
        return []

    def save_tasks(self):
        """Save tasks to JSON file"""
        with open(self.storage_file, 'w') as f:
            json.dump(self.tasks, f, indent=2)

    def add_task(self, description, deadline=None, priority='medium'):
        """Add a new task"""
        task = {
            'id': len(self.tasks) + 1,
            'description': description,
            'deadline': deadline,
            'priority': priority,
            'status': 'pending',
            'created': datetime.now().isoformat()
        }
        self.tasks.append(task)
        self.save_tasks()
        return task

    def list_tasks(self, filter_status=None):
        """List all tasks (optionally filtered)"""
        if filter_status:
            return [t for t in self.tasks if t['status'] == filter_status]
        return self.tasks

    def complete_task(self, task_id):
        """Mark task as completed"""
        for task in self.tasks:
            if task['id'] == task_id:
                task['status'] = 'completed'
                task['completed_date'] = datetime.now().isoformat()
                self.save_tasks()
                return task
        return None

    def delete_task(self, task_id):
        """Delete a task"""
        original_len = len(self.tasks)
        self.tasks = [t for t in self.tasks if t['id'] != task_id]
        if len(self.tasks) < original_len:
            self.save_tasks()
            return True
        return False

    def get_stats(self):
        """Get task statistics"""
        total = len(self.tasks)
        completed = sum(1 for t in self.tasks if t['status'] == 'completed')
        pending = sum(1 for t in self.tasks if t['status'] == 'pending')
        high_priority = sum(1 for t in self.tasks if t['priority'] == 'high')
        return {
            'total': total,
            'completed': completed,
            'pending': pending,
            'high_priority': high_priority,
            'completion_rate': (completed/total*100) if total > 0 else 0
        }

def print_header():
    """Print application header"""
    print("\n" + "="*70)
    print("[OK] PERSONAL TASK MANAGER - AI-Powered Task Management")
    print("="*70 + "\n")

def print_menu():
    """Print main menu"""
    print("\n[LIST] MENU:")
    print("  [1] Add Task")
    print("  [2] List All Tasks")
    print("  [3] List Pending Tasks")
    print("  [4] Mark Task Complete")
    print("  [5] Delete Task")
    print("  [6] View Statistics")
    print("  [7] Exit")
    print()

def display_task(task):
    """Display a single task"""
    status_icon = "[OK]" if task['status'] == 'completed' else "[WAIT]"
    priority_color = "[RED]" if task['priority'] == 'high' else "[YELLOW]" if task['priority'] == 'medium' else "[GREEN]"

    deadline_str = f" | Deadline: {task['deadline']}" if task['deadline'] else ""
    print(f"{status_icon} [{task['id']}] {task['description']} {priority_color}{deadline_str}")

def main():
    """Main application loop"""
    manager = TaskManager()
    print_header()
    print("Welcome to Personal Task Manager!")
    print("Your tasks are automatically saved to: tasks.json\n")

    while True:
        print_menu()
        choice = input("Enter your choice (1-7): ").strip()

        if choice == '1':
            # Add task
            desc = input("\n[NOTES] Enter task description: ").strip()
            deadline = input("[DATE] Enter deadline (optional, e.g., 2026-05-15): ").strip() or None
            priority = input("[TARGET] Priority (high/medium/low, default=medium): ").strip() or 'medium'

            task = manager.add_task(desc, deadline, priority)
            print(f"\n[OK] Task added! (ID: {task['id']})")

        elif choice == '2':
            # List all tasks
            tasks = manager.list_tasks()
            if not tasks:
                print("\n📭 No tasks yet. Add one to get started!")
            else:
                print(f"\n[LIST] All Tasks ({len(tasks)} total):")
                for task in tasks:
                    display_task(task)

        elif choice == '3':
            # List pending tasks
            tasks = manager.list_tasks(filter_status='pending')
            if not tasks:
                print("\n[DONE] No pending tasks! Great job!")
            else:
                print(f"\n[LIST] Pending Tasks ({len(tasks)} total):")
                for task in tasks:
                    display_task(task)

        elif choice == '4':
            # Complete task
            tasks = manager.list_tasks()
            if not tasks:
                print("\n📭 No tasks to complete!")
            else:
                print("\n[LIST] Your Tasks:")
                for task in tasks:
                    display_task(task)

                try:
                    task_id = int(input("\nEnter task ID to complete: "))
                    completed = manager.complete_task(task_id)
                    if completed:
                        print(f"[OK] Task marked as completed!")
                    else:
                        print(f"[FAIL] Task not found!")
                except ValueError:
                    print("[FAIL] Invalid ID!")

        elif choice == '5':
            # Delete task
            tasks = manager.list_tasks()
            if not tasks:
                print("\n📭 No tasks to delete!")
            else:
                print("\n[LIST] Your Tasks:")
                for task in tasks:
                    display_task(task)

                try:
                    task_id = int(input("\nEnter task ID to delete: "))
                    if manager.delete_task(task_id):
                        print(f"[DELETE] Task deleted!")
                    else:
                        print(f"[FAIL] Task not found!")
                except ValueError:
                    print("[FAIL] Invalid ID!")

        elif choice == '6':
            # Statistics
            stats = manager.get_stats()
            print(f"\n[CHART] TASK STATISTICS:")
            print(f"   Total Tasks: {stats['total']}")
            print(f"   Completed: {stats['completed']}")
            print(f"   Pending: {stats['pending']}")
            print(f"   High Priority: {stats['high_priority']}")
            print(f"   Completion Rate: {stats['completion_rate']:.1f}%")

        elif choice == '7':
            print("\n[BYE] Thank you for using Task Manager!")
            print("="*70 + "\n")
            break

        else:
            print("\n[FAIL] Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
