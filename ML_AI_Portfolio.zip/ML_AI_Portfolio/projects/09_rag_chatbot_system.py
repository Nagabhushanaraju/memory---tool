"""
RAG CHATBOT SYSTEM
Retrieval-Augmented Generation with Embeddings & Vector Search
Performance: Semantic retrieval with LLM generation
"""

import numpy as np
import json
from datetime import datetime
import hashlib

print("="*70)
print("[ROBOT] RAG CHATBOT SYSTEM - Retrieval-Augmented Generation")
print("="*70)

# ==================== SIMULATE EMBEDDINGS ====================
class SimpleEmbedding:
    """Simulates word embeddings for demonstration"""
    def __init__(self):
        self.vocab = {}
        self.embedding_dim = 300

    def text_to_embedding(self, text):
        """Convert text to numerical embedding"""
        words = text.lower().split()
        embedding = np.zeros(self.embedding_dim)

        for word in words:
            if word not in self.vocab:
                # Simulated word hash to embedding
                hash_val = int(hashlib.md5(word.encode()).hexdigest(), 16)
                np.random.seed(hash_val % (2**31))
                self.vocab[word] = np.random.randn(self.embedding_dim)

            embedding += self.vocab[word]

        # Normalize
        norm = np.linalg.norm(embedding)
        if norm > 0:
            embedding = embedding / norm

        return embedding

    def cosine_similarity(self, emb1, emb2):
        """Calculate cosine similarity between embeddings"""
        return np.dot(emb1, emb2) / (np.linalg.norm(emb1) * np.linalg.norm(emb2) + 1e-8)

# ==================== RAG KNOWLEDGE BASE ====================
class RAGChatbot:
    def __init__(self):
        self.embedder = SimpleEmbedding()
        self.knowledge_base = []
        self.conversation_history = []
        self.retrieved_docs = []

    def add_documents(self, documents):
        """Add documents to knowledge base"""
        print(f"\n[1/5] Adding documents to knowledge base...")
        for i, doc in enumerate(documents):
            embedding = self.embedder.text_to_embedding(doc['content'])
            self.knowledge_base.append({
                'id': i,
                'title': doc['title'],
                'content': doc['content'],
                'embedding': embedding,
                'added_at': datetime.now().isoformat()
            })
        print(f"[OK] {len(self.knowledge_base)} documents indexed")

    def retrieve_documents(self, query, top_k=3):
        """Retrieve similar documents using embedding similarity"""
        if not self.knowledge_base:
            return []

        query_embedding = self.embedder.text_to_embedding(query)

        # Calculate similarities
        similarities = []
        for doc in self.knowledge_base:
            sim = self.embedder.cosine_similarity(query_embedding, doc['embedding'])
            similarities.append({
                'id': doc['id'],
                'title': doc['title'],
                'content': doc['content'],
                'similarity': sim
            })

        # Sort by similarity and return top-k
        similarities.sort(key=lambda x: x['similarity'], reverse=True)
        self.retrieved_docs = similarities[:top_k]
        return self.retrieved_docs

    def generate_response(self, query):
        """Generate response using retrieved documents (simulated LLM)"""
        retrieved = self.retrieve_documents(query)

        if not retrieved:
            return "No relevant information found in knowledge base."

        # Simulate LLM response based on retrieved docs
        response = f"Based on the knowledge base, here's what I found:\n\n"

        for i, doc in enumerate(retrieved, 1):
            response += f"{i}. **{doc['title']}** (Relevance: {doc['similarity']:.2%})\n"
            response += f"   {doc['content'][:100]}...\n\n"

        return response

    def chat(self, user_message):
        """Process user message and generate response"""
        # Retrieve relevant documents
        response = self.generate_response(user_message)

        # Store conversation
        self.conversation_history.append({
            'role': 'user',
            'message': user_message,
            'timestamp': datetime.now().isoformat()
        })

        self.conversation_history.append({
            'role': 'assistant',
            'message': response,
            'timestamp': datetime.now().isoformat(),
            'retrieved_docs': len(self.retrieved_docs)
        })

        return response

# ==================== INITIALIZE CHATBOT ====================
print("\n[1/5] Initializing RAG Chatbot...")
chatbot = RAGChatbot()

# Sample knowledge base
documents = [
    {
        'title': 'Machine Learning Basics',
        'content': 'Machine learning is a subset of artificial intelligence that enables systems to learn and improve from experience without being explicitly programmed.'
    },
    {
        'title': 'Neural Networks',
        'content': 'Neural networks are computing systems inspired by biological neural networks. They consist of interconnected nodes that work together to process information.'
    },
    {
        'title': 'Deep Learning',
        'content': 'Deep learning is a subset of machine learning that uses neural networks with multiple layers. It excels at processing unstructured data like images and text.'
    },
    {
        'title': 'Natural Language Processing',
        'content': 'NLP is a branch of AI that focuses on understanding and generating human language. Applications include sentiment analysis, machine translation, and chatbots.'
    },
    {
        'title': 'Computer Vision',
        'content': 'Computer vision enables machines to interpret and understand the visual world. It uses deep learning to analyze images and videos for various applications.'
    },
    {
        'title': 'Reinforcement Learning',
        'content': 'Reinforcement learning is a paradigm where an agent learns by interacting with an environment and receiving rewards or penalties for its actions.'
    }
]

chatbot.add_documents(documents)

# ==================== DEMONSTRATION ====================
print("\n[2/5] Setting up retrieval system...")
print(f"[OK] Embedding dimension: {chatbot.embedder.embedding_dim}")
print(f"[OK] Knowledge base size: {len(chatbot.knowledge_base)} documents")

print("\n[3/5] Testing retrieval with sample queries...")
test_queries = [
    "Tell me about neural networks",
    "How does deep learning work?",
    "What is NLP?",
    "Explain machine learning"
]

retrieval_results = {}
for query in test_queries:
    print(f"\n   Query: '{query}'")
    retrieved = chatbot.retrieve_documents(query, top_k=2)
    retrieval_results[query] = []

    for i, doc in enumerate(retrieved, 1):
        print(f"   [{i}] {doc['title']} (Relevance: {doc['similarity']:.2%})")
        retrieval_results[query].append({
            'title': doc['title'],
            'relevance': f"{doc['similarity']:.2%}"
        })

# ==================== INTERACTIVE CONVERSATION ====================
print("\n[4/5] Running interactive chat session...")
print("="*70)

user_queries = [
    "What are neural networks?",
    "How is deep learning different from machine learning?",
    "Tell me about natural language processing"
]

for i, query in enumerate(user_queries, 1):
    print(f"\n[USER] User: {query}")
    print("-" * 70)
    response = chatbot.chat(query)
    print(f"[ROBOT] Assistant:\n{response}")

# ==================== STATISTICS & ANALYSIS ====================
print("\n[5/5] Conversation Statistics:")
print("="*70)

print(f"\n[CHART] SESSION METRICS:")
print(f"   Total messages: {len(chatbot.conversation_history)}")
print(f"   User queries: {len([m for m in chatbot.conversation_history if m['role'] == 'user'])}")
print(f"   Assistant responses: {len([m for m in chatbot.conversation_history if m['role'] == 'assistant'])}")
print(f"   Average docs retrieved per query: {np.mean([m.get('retrieved_docs', 0) for m in chatbot.conversation_history if m['role'] == 'assistant']):.1f}")

# ==================== VISUALIZATION ====================
import matplotlib.pyplot as plt

fig, axes = plt.subplots(2, 2, figsize=(14, 10))

# 1. Retrieval Performance
ax1 = axes[0, 0]
queries = list(retrieval_results.keys())
relevances = [max([float(doc['relevance'].strip('%'))/100 for doc in retrieval_results[q]]) for q in queries]
colors = ['#2ecc71' if r > 0.7 else '#f39c12' if r > 0.4 else '#e74c3c' for r in relevances]
ax1.barh(range(len(queries)), relevances, color=colors, alpha=0.7)
ax1.set_yticks(range(len(queries)))
ax1.set_yticklabels([q[:30] + "..." if len(q) > 30 else q for q in queries], fontsize=9)
ax1.set_xlabel('Max Relevance Score')
ax1.set_title('Query Retrieval Performance', fontweight='bold')
ax1.set_xlim([0, 1])
ax1.grid(True, alpha=0.3, axis='x')

# 2. Document Frequency
ax2 = axes[0, 1]
doc_titles = [doc['title'] for doc in documents]
doc_freq = {}
for doc_list in retrieval_results.values():
    for doc in doc_list:
        doc_freq[doc['title']] = doc_freq.get(doc['title'], 0) + 1

titles = list(doc_freq.keys())
frequencies = list(doc_freq.values())
colors = plt.cm.viridis(np.linspace(0, 1, len(titles)))
ax2.bar(range(len(titles)), frequencies, color=colors, alpha=0.7)
ax2.set_xticks(range(len(titles)))
ax2.set_xticklabels([t[:15] + "..." if len(t) > 15 else t for t in titles], rotation=45, ha='right', fontsize=8)
ax2.set_ylabel('Times Retrieved')
ax2.set_title('Document Retrieval Frequency', fontweight='bold')
ax2.grid(True, alpha=0.3, axis='y')

# 3. Conversation Flow
ax3 = axes[1, 0]
roles = ['User Messages', 'Assistant Responses']
counts = [
    len([m for m in chatbot.conversation_history if m['role'] == 'user']),
    len([m for m in chatbot.conversation_history if m['role'] == 'assistant'])
]
ax3.pie(counts, labels=roles, autopct='%1.1f%%', colors=['#3498db', '#e74c3c'], startangle=90)
ax3.set_title('Conversation Composition', fontweight='bold')

# 4. System Information
ax4 = axes[1, 1]
ax4.axis('off')
info_text = f"""
[ROBOT] RAG CHATBOT SYSTEM OVERVIEW
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Knowledge Base:
  • Documents: {len(chatbot.knowledge_base)}
  • Embedding dim: {chatbot.embedder.embedding_dim}
  • Retrieval method: Cosine similarity

Performance:
  • Avg relevance: {np.mean(relevances):.2%}
  • Messages processed: {len(chatbot.conversation_history)}
  • Response time: Instant (simulated)

Architecture:
  1. Document ingestion
  2. Embedding generation
  3. Query embedding
  4. Similarity search
  5. LLM response generation

Status: [OK] Operational
Next: Deploy with real LLM API
"""

ax4.text(0.05, 0.95, info_text, transform=ax4.transAxes,
        fontfamily='monospace', fontsize=10, verticalalignment='top',
        bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.3))

plt.tight_layout()
plt.savefig('rag_chatbot_analysis.png', dpi=150, bbox_inches='tight')
print("\n[OK] Analysis saved: rag_chatbot_analysis.png")

# ==================== SAVE CONVERSATION ====================
print("\n[SAVE] Saving conversation log...")
conversation_log = {
    'session_info': {
        'created_at': datetime.now().isoformat(),
        'knowledge_base_size': len(chatbot.knowledge_base),
        'total_messages': len(chatbot.conversation_history),
        'retrieval_accuracy': np.mean(relevances)
    },
    'conversation': chatbot.conversation_history
}

with open('rag_conversation_log.json', 'w') as f:
    json.dump(conversation_log, f, indent=2, default=str)
print("[OK] Conversation saved: rag_conversation_log.json")

print("\n" + "="*70)
print("[DONE] RAG Chatbot System Complete!")
print("="*70)
