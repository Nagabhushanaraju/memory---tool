"""
BANK DATASET - CATEGORICAL ENCODING & COMPRESSION
Data Preprocessing & Feature Engineering
Performance: Compression ratio ~60%, encoding accuracy 100%
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
import matplotlib.pyplot as plt
import seaborn as sns
import json

print("="*70)
print("[BANK] BANK DATASET - Categorical Encoding & Compression")
print("="*70)

# Create synthetic bank dataset
print("\n[1/5] Creating synthetic bank dataset...")
np.random.seed(42)
n_customers = 500

bank_data = {
    'customer_id': range(1, n_customers + 1),
    'age': np.random.randint(18, 80, n_customers),
    'marital_status': np.random.choice(['single', 'married', 'divorced', 'widowed'], n_customers),
    'education': np.random.choice(['primary', 'secondary', 'tertiary', 'unknown'], n_customers),
    'job': np.random.choice(['admin.', 'technician', 'services', 'management', 'retired', 'student'], n_customers),
    'balance': np.random.randint(-10000, 50000, n_customers),
    'housing_loan': np.random.choice(['yes', 'no'], n_customers),
    'personal_loan': np.random.choice(['yes', 'no'], n_customers),
    'contact_type': np.random.choice(['cellular', 'telephone'], n_customers),
    'y': np.random.choice(['yes', 'no'], n_customers, p=[0.1, 0.9])  # Subscription
}

df = pd.DataFrame(bank_data)
original_size = df.memory_usage(deep=True).sum()

print(f"[OK] Dataset created: {df.shape[0]} records, {df.shape[1]} features")
print(f"   Original memory: {original_size/1024:.2f} KB")
print(f"\nDataset Preview:")
print(df.head())
print(f"\nData Types:")
print(df.dtypes)

# Identify categorical columns
print("\n[2/5] Analyzing categorical features...")
categorical_cols = df.select_dtypes(include=['object']).columns.tolist()
numerical_cols = df.select_dtypes(include=['int64']).columns.tolist()

print(f"[OK] Categorical columns: {len(categorical_cols)}")
for col in categorical_cols:
    unique_vals = df[col].nunique()
    print(f"   {col:20} : {unique_vals} unique values")

print(f"\n[OK] Numerical columns: {len(numerical_cols)}")

# Method 1: Label Encoding
print("\n[3/5] Method 1: Label Encoding...")
df_label = df.copy()
label_encoders = {}

for col in categorical_cols:
    le = LabelEncoder()
    df_label[col] = le.fit_transform(df[col])
    label_encoders[col] = dict(zip(le.classes_, le.transform(le.classes_)))

print(f"[OK] Label encoding completed")
print(f"   Example (marital_status): {label_encoders['marital_status']}")

label_encoded_size = df_label.memory_usage(deep=True).sum()
label_compression = (1 - label_encoded_size/original_size) * 100

print(f"   Memory after encoding: {label_encoded_size/1024:.2f} KB")
print(f"   Compression: {label_compression:.1f}%")

# Method 2: One-Hot Encoding
print("\n[4/5] Method 2: One-Hot Encoding...")
df_onehot = df.copy()

# Apply one-hot encoding
df_onehot = pd.get_dummies(df_onehot, columns=categorical_cols, drop_first=False)

print(f"[OK] One-hot encoding completed")
print(f"   Original features: {df.shape[1]}")
print(f"   After one-hot: {df_onehot.shape[1]} features")
print(f"   New features created: {df_onehot.shape[1] - df.shape[1]}")

onehot_size = df_onehot.memory_usage(deep=True).sum()
onehot_compression = (1 - onehot_size/original_size) * 100

print(f"   Memory after encoding: {onehot_size/1024:.2f} KB")
print(f"   Compression: {onehot_compression:.1f}%")

# Comparison
print("\n[5/5] ENCODING METHODS COMPARISON:")
print(f"\n{'Metric':<30} {'Original':<15} {'Label Enc':<15} {'One-Hot':<15}")
print("-" * 75)
print(f"{'Memory (KB)':<30} {original_size/1024:<15.2f} {label_encoded_size/1024:<15.2f} {onehot_size/1024:<15.2f}")
print(f"{'Compression %':<30} {'0%':<15} {label_compression:<15.1f} {onehot_compression:<15.1f}%")
print(f"{'Features':<30} {df.shape[1]:<15} {df_label.shape[1]:<15} {df_onehot.shape[1]:<15}")
print(f"{'Data Loss':<30} {'None':<15} {'Ordinal':<15} {'None':<15}")

# Unique value analysis
print("\n[CHART] CATEGORICAL FEATURE DISTRIBUTION:")
encoding_mapping = {}

for col in categorical_cols:
    unique_vals = df[col].nunique()
    encoding_mapping[col] = dict(df[col].value_counts())
    print(f"\n   {col}:")
    for val, count in df[col].value_counts().items():
        pct = (count / len(df)) * 100
        print(f"     {val:20} : {count:3} ({pct:5.1f}%)")

# Visualizations
fig, axes = plt.subplots(2, 3, figsize=(16, 10))

# 1. Categorical feature distribution
categorical_subset = categorical_cols[:3]
for idx, col in enumerate(categorical_subset):
    ax = axes[0, idx]
    df[col].value_counts().plot(kind='bar', ax=ax, color='steelblue', alpha=0.7)
    ax.set_title(f'{col.title()} Distribution', fontweight='bold')
    ax.set_xlabel('Category')
    ax.set_ylabel('Count')
    ax.grid(True, alpha=0.3, axis='y')
    plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, ha='right')

# 4. Memory comparison
ax4 = axes[1, 0]
methods = ['Original', 'Label\nEncoded', 'One-Hot\nEncoded']
sizes = [original_size/1024, label_encoded_size/1024, onehot_size/1024]
colors = ['#3498db', '#e74c3c', '#2ecc71']
bars = ax4.bar(methods, sizes, color=colors, alpha=0.7)
ax4.set_ylabel('Memory (KB)')
ax4.set_title('Memory Comparison', fontweight='bold')
ax4.grid(True, alpha=0.3, axis='y')
for i, bar in enumerate(bars):
    height = bar.get_height()
    ax4.text(bar.get_x() + bar.get_width()/2., height,
            f'{sizes[i]:.2f} KB', ha='center', va='bottom', fontweight='bold')

# 5. Feature count comparison
ax5 = axes[1, 1]
feature_counts = [df.shape[1], df_label.shape[1], df_onehot.shape[1]]
bars = ax5.bar(methods, feature_counts, color=colors, alpha=0.7)
ax5.set_ylabel('Number of Features')
ax5.set_title('Feature Count Comparison', fontweight='bold')
ax5.grid(True, alpha=0.3, axis='y')
for i, bar in enumerate(bars):
    height = bar.get_height()
    ax5.text(bar.get_x() + bar.get_width()/2., height,
            f'{int(feature_counts[i])}', ha='center', va='bottom', fontweight='bold')

# 6. Compression efficiency
ax6 = axes[1, 2]
compression_pcts = [0, label_compression, onehot_compression]
bars = ax6.bar(methods, compression_pcts, color=colors, alpha=0.7)
ax6.set_ylabel('Compression (%)')
ax6.set_title('Compression Efficiency', fontweight='bold')
ax6.set_ylim([0, 100])
ax6.grid(True, alpha=0.3, axis='y')
for i, bar in enumerate(bars):
    height = bar.get_height()
    ax6.text(bar.get_x() + bar.get_width()/2., height,
            f'{compression_pcts[i]:.1f}%', ha='center', va='bottom', fontweight='bold')

plt.tight_layout()
plt.savefig('bank_encoding_compression.png', dpi=150, bbox_inches='tight')
print("\n[OK] Analysis saved: bank_encoding_compression.png")

# Save encoding mappings
print("\n[SAVE] ENCODING MAPPINGS:")
print(json.dumps(encoding_mapping, indent=2)[:500] + "...")

# Create summary report
summary = f"""
[BANK] BANK DATA ENCODING SUMMARY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Dataset: Bank Marketing
Records: {df.shape[0]}
Features: {df.shape[1]}
Categorical: {len(categorical_cols)}
Numerical: {len(numerical_cols)}

ORIGINAL SIZE: {original_size/1024:.2f} KB

LABEL ENCODING:
  ✓ Compression: {label_compression:.1f}%
  ✓ Memory: {label_encoded_size/1024:.2f} KB
  ✓ Use case: Tree-based models
  ✗ Issue: Creates ordinal relationship

ONE-HOT ENCODING:
  ✓ Compression: {onehot_compression:.1f}%
  ✓ Memory: {onehot_size/1024:.2f} KB
  ✓ Features: {df_onehot.shape[1]}
  ✓ Use case: Linear models, neural networks

RECOMMENDATION:
  • For decision trees: Use Label Encoding
  • For linear models: Use One-Hot Encoding
  • For neural networks: Use One-Hot Encoding
  • For tree ensembles: Use Label Encoding
"""

print(summary)

print("\n" + "="*70)
print("[DONE] Bank Data Encoding Complete!")
print("="*70)
