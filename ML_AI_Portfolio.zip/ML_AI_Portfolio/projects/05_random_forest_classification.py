"""
RANDOM FOREST CLASSIFICATION
Ensemble Learning on Income Prediction
Performance: ~86% accuracy
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.preprocessing import LabelEncoder
import matplotlib.pyplot as plt
import seaborn as sns

print("="*70)
print("[TREE] RANDOM FOREST CLASSIFICATION - Ensemble Learning")
print("="*70)

# Create sample dataset
print("\n[1/4] Creating sample income dataset...")
np.random.seed(42)
n_samples = 500

data = {
    'age': np.random.randint(20, 70, n_samples),
    'years_education': np.random.randint(8, 20, n_samples),
    'hours_per_week': np.random.randint(10, 60, n_samples),
    'capital_gain': np.random.randint(0, 100000, n_samples),
    'capital_loss': np.random.randint(0, 10000, n_samples),
    'fnlwgt': np.random.randint(10000, 1000000, n_samples),
}

# Create target based on features
y = ((data['age'] > 40) & (data['years_education'] > 12) & (data['capital_gain'] > 5000)).astype(int)
df = pd.DataFrame(data)
df['income'] = y

print(f"[OK] Dataset created: {df.shape[0]} samples, {df.shape[1]} features")
print(f"   - Income > 50K: {y.sum()} ({y.sum()/len(y)*100:.1f}%)")
print(f"   - Income ≤ 50K: {len(y)-y.sum()} ({(len(y)-y.sum())/len(y)*100:.1f}%)")

# Prepare data
print("\n[2/4] Preparing data...")
X = df.drop('income', axis=1)
y = df['income']
X_trn, X_tst, y_trn, y_tst = train_test_split(X, y, test_size=0.2, random_state=42)
print(f"[OK] Train: {X_trn.shape[0]}, Test: {X_tst.shape[0]}")

# Train Random Forest
print("\n[3/4] Training models...")
print("   Random Forest (100 trees)...")
rf_model = RandomForestClassifier(n_estimators=100, random_state=42, max_depth=10)
rf_model.fit(X_trn, y_trn)

print("   Decision Tree (baseline)...")
dt_model = DecisionTreeClassifier(random_state=42, max_depth=10)
dt_model.fit(X_trn, y_trn)

# Evaluate
print("\n[4/4] Evaluation Results:")
rf_pred = rf_model.predict(X_tst)
dt_pred = dt_model.predict(X_tst)

rf_acc = accuracy_score(y_tst, rf_pred)
dt_acc = accuracy_score(y_tst, dt_pred)

print(f"\n[CHART] Random Forest Accuracy: {rf_acc*100:.2f}%")
print(f"[CHART] Decision Tree Accuracy: {dt_acc*100:.2f}%")
print(f"[OK] Improvement: {(rf_acc-dt_acc)*100:.2f}%")

print("\n[TARGET] Random Forest Classification Report:")
print(classification_report(y_tst, rf_pred, target_names=['≤50K', '>50K']))

# Feature importance
print("\n[GRAPH] Top 5 Important Features:")
feature_importance = pd.DataFrame({
    'feature': X.columns,
    'importance': rf_model.feature_importances_
}).sort_values('importance', ascending=False)

for idx, row in feature_importance.head(5).iterrows():
    print(f"   {row['feature']}: {row['importance']:.4f}")

# Visualizations
fig, axes = plt.subplots(2, 2, figsize=(14, 10))

# Confusion matrices
cm_rf = confusion_matrix(y_tst, rf_pred)
cm_dt = confusion_matrix(y_tst, dt_pred)

sns.heatmap(cm_rf, annot=True, fmt='d', ax=axes[0, 0], cmap='Blues')
axes[0, 0].set_title(f'Random Forest (Accuracy: {rf_acc*100:.1f}%)')
axes[0, 0].set_ylabel('True')
axes[0, 0].set_xlabel('Predicted')

sns.heatmap(cm_dt, annot=True, fmt='d', ax=axes[0, 1], cmap='Oranges')
axes[0, 1].set_title(f'Decision Tree (Accuracy: {dt_acc*100:.1f}%)')
axes[0, 1].set_ylabel('True')
axes[0, 1].set_xlabel('Predicted')

# Feature importance
top_features = feature_importance.head(10)
axes[1, 0].barh(top_features['feature'], top_features['importance'], color='steelblue')
axes[1, 0].set_title('Top 10 Feature Importance')
axes[1, 0].set_xlabel('Importance')

# Model comparison
models = ['Random Forest', 'Decision Tree']
accuracies = [rf_acc*100, dt_acc*100]
axes[1, 1].bar(models, accuracies, color=['steelblue', 'orange'])
axes[1, 1].set_title('Model Accuracy Comparison')
axes[1, 1].set_ylabel('Accuracy (%)')
axes[1, 1].set_ylim([0, 100])

plt.tight_layout()
plt.savefig('random_forest_analysis.png', dpi=150, bbox_inches='tight')
print("\n[OK] Analysis saved: random_forest_analysis.png")

print("\n" + "="*70)
print("[DONE] Random Forest Classification Complete!")
print("="*70)
