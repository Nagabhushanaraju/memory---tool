"""
LINEAR REGRESSION - HOUSING PRICE PREDICTION
Regression Analysis & Model Evaluation
Performance: R² score ~0.85
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import matplotlib.pyplot as plt
import seaborn as sns

print("="*70)
print("[HOUSE] LINEAR REGRESSION - Housing Price Prediction")
print("="*70)

# Create synthetic housing dataset
print("\n[1/5] Creating synthetic housing dataset...")
np.random.seed(42)
n_samples = 200

data = {
    'square_feet': np.random.uniform(800, 4000, n_samples),
    'bedrooms': np.random.randint(1, 6, n_samples),
    'bathrooms': np.random.randint(1, 4, n_samples),
    'age': np.random.randint(0, 50, n_samples),
    'distance_to_city': np.random.uniform(0.5, 30, n_samples),
}

df = pd.DataFrame(data)

# Generate price based on features (realistic relationship)
df['price'] = (
    df['square_feet'] * 150 +          # $150 per sq ft
    df['bedrooms'] * 50000 +           # $50k per bedroom
    df['bathrooms'] * 30000 +          # $30k per bathroom
    df['age'] * (-1000) +              # -$1k per year of age
    df['distance_to_city'] * (-2000) + # -$2k per mile
    np.random.normal(0, 50000, n_samples)  # Noise
)

print(f"[OK] Dataset created: {df.shape[0]} properties")
print(f"\nDataset Summary:")
print(df.describe().round(2))

# Prepare data
print("\n[2/5] Preparing data for training...")
X = df[['square_feet', 'bedrooms', 'bathrooms', 'age', 'distance_to_city']]
y = df['price']

X_trn, X_tst, y_trn, y_tst = train_test_split(X, y, test_size=0.2, random_state=42)
print(f"[OK] Train: {X_trn.shape[0]}, Test: {X_tst.shape[0]}")

# Scale features
print("\n[3/5] Scaling features...")
scaler = StandardScaler()
X_trn_scaled = scaler.fit_transform(X_trn)
X_tst_scaled = scaler.transform(X_tst)
print(f"[OK] Features normalized using StandardScaler")

# Train model
print("\n[4/5] Training Linear Regression model...")
model = LinearRegression()
model.fit(X_trn_scaled, y_trn)
print(f"[OK] Model trained successfully")

# Make predictions
print("\n[5/5] Evaluating performance...")
y_trn_pred = model.predict(X_trn_scaled)
y_tst_pred = model.predict(X_tst_scaled)

# Calculate metrics
train_rmse = np.sqrt(mean_squared_error(y_trn, y_trn_pred))
test_rmse = np.sqrt(mean_squared_error(y_tst, y_tst_pred))
train_mae = mean_absolute_error(y_trn, y_trn_pred)
test_mae = mean_absolute_error(y_tst, y_tst_pred)
train_r2 = r2_score(y_trn, y_trn_pred)
test_r2 = r2_score(y_tst, y_tst_pred)

print(f"\n[CHART] REGRESSION METRICS:")
print(f"\n   Train Set:")
print(f"     RMSE: ${train_rmse:,.2f}")
print(f"     MAE:  ${train_mae:,.2f}")
print(f"     R²:   {train_r2:.4f}")
print(f"\n   Test Set:")
print(f"     RMSE: ${test_rmse:,.2f}")
print(f"     MAE:  ${test_mae:,.2f}")
print(f"     R²:   {test_r2:.4f}")

# Feature coefficients
print(f"\n[GRAPH] FEATURE IMPORTANCE (Coefficients):")
feature_names = X.columns
coefficients = pd.DataFrame({
    'feature': feature_names,
    'coefficient': model.coef_
}).sort_values('coefficient', ascending=False)

for idx, row in coefficients.iterrows():
    impact = "↑" if row['coefficient'] > 0 else "↓"
    print(f"   {impact} {row['feature']:20} : {row['coefficient']:>10,.2f}")

print(f"   Intercept: ${model.intercept_:,.2f}")

# Visualizations
fig, axes = plt.subplots(2, 2, figsize=(14, 10))

# 1. Actual vs Predicted (Train)
axes[0, 0].scatter(y_trn, y_trn_pred, alpha=0.6, s=50, color='steelblue')
axes[0, 0].plot([y_trn.min(), y_trn.max()], [y_trn.min(), y_trn.max()],
                'r--', lw=2, label='Perfect Fit')
axes[0, 0].set_xlabel('Actual Price ($)')
axes[0, 0].set_ylabel('Predicted Price ($)')
axes[0, 0].set_title(f'Training Set: Actual vs Predicted (R²={train_r2:.4f})')
axes[0, 0].legend()
axes[0, 0].grid(True, alpha=0.3)

# 2. Actual vs Predicted (Test)
axes[0, 1].scatter(y_tst, y_tst_pred, alpha=0.6, s=50, color='coral')
axes[0, 1].plot([y_tst.min(), y_tst.max()], [y_tst.min(), y_tst.max()],
                'r--', lw=2, label='Perfect Fit')
axes[0, 1].set_xlabel('Actual Price ($)')
axes[0, 1].set_ylabel('Predicted Price ($)')
axes[0, 1].set_title(f'Test Set: Actual vs Predicted (R²={test_r2:.4f})')
axes[0, 1].legend()
axes[0, 1].grid(True, alpha=0.3)

# 3. Residuals
residuals = y_tst - y_tst_pred
axes[1, 0].scatter(y_tst_pred, residuals, alpha=0.6, s=50, color='green')
axes[1, 0].axhline(y=0, color='r', linestyle='--', lw=2)
axes[1, 0].set_xlabel('Predicted Price ($)')
axes[1, 0].set_ylabel('Residuals ($)')
axes[1, 0].set_title('Residual Plot (Test Set)')
axes[1, 0].grid(True, alpha=0.3)

# 4. Feature Importance
colors = ['green' if x > 0 else 'red' for x in coefficients['coefficient']]
axes[1, 1].barh(coefficients['feature'], coefficients['coefficient'], color=colors, alpha=0.7)
axes[1, 1].set_xlabel('Coefficient Value')
axes[1, 1].set_title('Feature Coefficients')
axes[1, 1].grid(True, alpha=0.3, axis='x')

plt.tight_layout()
plt.savefig('linear_regression_housing.png', dpi=150, bbox_inches='tight')
print("\n[OK] Analysis saved: linear_regression_housing.png")

# Sample predictions
print("\n[HOUSE] SAMPLE PREDICTIONS (Test Set):")
print(f"\n{'Property':<10} {'Actual Price':<15} {'Predicted':<15} {'Error':<12} {'%':<8}")
print("-" * 60)
for i in range(5):
    actual = y_tst.iloc[i]
    pred = y_tst_pred[i]
    error = abs(actual - pred)
    pct_error = (error / actual) * 100
    print(f"  {i+1:<9} ${actual:>13,.0f} ${pred:>13,.0f} ${error:>10,.0f} {pct_error:>6.2f}%")

print("\n" + "="*70)
print("[DONE] Linear Regression Complete!")
print("="*70)
