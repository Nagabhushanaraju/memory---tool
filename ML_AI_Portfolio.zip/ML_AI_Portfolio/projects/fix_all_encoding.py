import os
import re

files = [
    '01_sms_spam_classifier.py',
    '02_waste_classification_cnn.py',
    '03_sentiment_analysis_rnn.py',
    '04_mnist_digit_recognition.py',
    '05_random_forest_classification.py',
    '06_linear_regression_housing.py',
    '07_decision_trees_analysis.py',
    '08_bank_encoding_compression.py',
    '09_rag_chatbot_system.py',
    '10_task_manager.py'
]

emoji_map = {
    '✅': '[OK]',
    '❌': '[FAIL]',
    '🏠': '[HOUSE]',
    '💬': '[CHAT]',
    '🤖': '[ROBOT]',
    '🔢': '[DIGIT]',
    '🌲': '[TREE]',
    '📧': '[EMAIL]',
    '🔮': '[MAGIC]',
    '💾': '[SAVE]',
    '📊': '[CHART]',
    '📈': '[GRAPH]',
    '⏸️': '[PAUSE]',
    '⚠️': '[WARN]',
    '🔋': '[BATTERY]',
    '📦': '[PACKAGE]',
    '🏦': '[BANK]',
    '🎉': '[DONE]',
    '♻️': '[RECYCLE]',
    '🍷': '[WINE]',
    '🔍': '[SEARCH]',
    '📋': '[LIST]',
    '🎯': '[TARGET]',
    '📝': '[NOTES]',
    '📅': '[DATE]',
    '👋': '[BYE]',
    '👤': '[USER]',
    '⏳': '[WAIT]',
    '🟢': '[GREEN]',
    '🟡': '[YELLOW]',
    '🔴': '[RED]',
    '🗑️': '[DELETE]',
}

for filename in files:
    if os.path.exists(filename):
        with open(filename, 'r', encoding='utf-8') as f:
            content = f.read()
        
        for emoji, text in emoji_map.items():
            content = content.replace(emoji, text)
        
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(content)
        
        print(f"Fixed: {filename}")

print("\nAll projects updated!")
