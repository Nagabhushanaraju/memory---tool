@echo off
REM ML-AI Portfolio Dashboard Launcher (v2 Enhanced)
REM Start the interactive dashboard

echo.
echo ========================================
echo   ML-AI PORTFOLIO DASHBOARD v2.0
echo ========================================
echo.

cd /d "%~dp0"

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed or not in PATH
    pause
    exit /b 1
)

echo Starting Enhanced Dashboard...
echo.

REM Launch the enhanced dashboard
python dashboard_v2.py

pause
